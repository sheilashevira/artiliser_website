@extends('layouts.adminbackend')
@section('content')

<div class="flex items-center justify-center">
  <div class="max-w-md py-4 px-8 shadow-lg rounded-lg my-20" style="background-color:#F7DAD9">
    <div class="flex items-center justify-center">
      <img class="w-36 h-36 object-cover rounded-full border-2 border-indigo-500" src="/img/{{ $data->image }}">
    </div>
      <h2 class="text-gray-800 text-1xl font-semibold text-center mt-2">Post Details</h2>
      <table class="grid justify-items-center mt-1">
          <td class="mt-2 text-gray-600" width="150px">Post Name</td>
          <td class="mt-2 text-gray-600">: {{ $data->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Category</td>
          <td class="mt-2 text-gray-600">: {{ $data->categories->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Carousel Row</td>
          <td class="mt-2 text-gray-600">: {{ $data->carousel_rows->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Print Material</td>
          <td class="mt-2 text-gray-600">: {{ $data->print_materials->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Print Type</td>
          <td class="mt-2 text-gray-600">: {{ $data->print_types->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Size</td>
          <td class="mt-2 text-gray-600">: {{ $data->sizes->name}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Price</td>
          <td class="mt-2 text-gray-600">: {{ $data->price}}</td>
        </tr>
        <tr>
          <td class="mt-2 text-gray-600">Content</td>
          <td class="mt-2 text-gray-600">: {{ $data->content}}</td>
        </tr>
    </table>
    <div class="flex justify-end mt-4">
       <a href="/user" class="inline-block px-6 bg-artiliser py-1 text-xs font-medium leading-6 text-center text-white transition rounded border shadow ripple hover:shadow-lg focus:outline-none ">Back</a>
    </div>
  </div>
</div>
{{-- 


<div class="shadow-md bg-white rounded px-10 pt-6 pb-8 mb-4 flex flex-col my-5 mx-3" >
  <div class="-mx-3 md:flex sm:mb-2">
    <div class="md:w-1/2 px-3">
      <label  class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-category" >
        Name
      </label>
      <input readonly value={{ $data->name}} class="w-full bg-grey-lighter border text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent" style="border-color:#670067" id="grid-name" type="text" placeholder="Input Post Name">
    </div>
  </div>
  <div class="-mx-3 md:flex sm:mb-2">
    <div class="md:w-1/2 px-3">
      <label  class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-category" >
        Category
      </label>
      <input readonlys value="{{ $data->categories->name}}" style="border-color:#670067" class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
    </div>
    <div class="md:w-1/2 px-3 sm:mb-6 mt-6 sm:mt-0">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-carousel-rows">
        Carousel Rows
      </label>
      <input readonly value="{{ $data->carousel_rows->name}}" style="border-color:#670067" class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
    </div>
  </div>
    <div class="-mx-3 md:flex mb-6 mt-6 sm:mt-0">
      <div id="printmaterials" class="md:w-1/2 px-3" hide>
        <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-print-materials">
          Print Materials
        </label>
        <input readonly value="{{ $data->print_materials->name}}" style="border-color:#670067" class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
      </div>
      <div class="md:w-1/2 px-3 mt-6 sm:mt-0">
        <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-print-types">
          Print Types
        </label>
        <input readonly value="{{ $data->print_types->name}}" style="border-color:#670067" class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
      </div>
      <div class="md:w-1/2 px-3 mt-6 sm:mt-0">
        <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-price">
          Size
        </label>
        <input readonly value="{{ $data->sizes->name}}" style="border-color:#670067" class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
      </div>
      <div class="md:w-1/2 px-3 mt-6 sm:mt-1">
        <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-price">
          Price
        </label>
        <input readonly value="{{ $data->price}}" class="appearance-none block w-full bg-grey-lighter text-sm text-grey-darker border rounded py-3 px-4 mb-3" style="border-color:#670067" id="grid-price" type="text" placeholder="Input Price">
      </div>
    </div>
  <div class="-mx-3 md:flex mb-6 mt-4 sm:mt-0">
    <div class="md:w-full px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-image">
        Image
      </label>
      <input value="{{ $data->image}}"style="border-color:#670067" class="appearance-none block w-full bg-grey-lighter text-sm text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3" id="grid-price" type="text">
      <img src="/img/{{ $data->image }}" width="300px">  
    </div>
  </div>
  <div class="-mx-3 md:flex mb-6">
    <div class="md:w-full px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" style="color:#670067" for="grid-price">
        Content
      </label>
      <textarea readonly name="content" class="border-2 border-gray-500">{{ $data->content}}</textarea>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'content' );
    </script>
    </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="inline-block px-6 bg-artiliser py-1 text-xs font-medium leading-6 text-center text-white transition rounded border shadow ripple hover:shadow-lg focus:outline-none">Save</button>
    <a href="/post" class="inline-block px-6 py-1 text-xs text-artiliser font-medium leading-6 text-center transition bg-transparent border border-artiliser rounded ripple focus:outline-none">Back</a>
  </div>
</form>
</div> --}}
@endsection

      
      
    