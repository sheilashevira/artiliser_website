<?php

namespace App\Http\Controllers\Backend;
use App\Models\Countries;
use App\Models\States;
use App\Models\Cities;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

// class AjaxLocation extends Controller
// {


//     public function countries(){
//         $countries = Countries::all();
//         return view('backend.user.edit', compact('countries'));
//     }

//     public function getStates(Request $request){
//         $states = States::where("country_id", $request->country_id)->pluck('id','name');
//         return response()->json($states);
//     }

//     public function getCities(Request $request){
//         $cities = Cities::where("state_id", $request->state_id)->pluck('id','name');
//         return response()->json($cities);
//     }
//  } 