<div>
    <p>This is livewire component</p>
</div>
