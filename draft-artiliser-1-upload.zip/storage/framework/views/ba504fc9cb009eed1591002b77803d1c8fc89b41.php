<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.0-canary.14/tailwind.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet"/>

    <link href='https://fonts.googleapis.com/css?family=Asap' rel='stylesheet'>
</head>
<body>
    <div class="relative min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 bg-gray-500 bg-no-repeat bg-cover relative items-center"
	style="background-image: url(https://www.kibrispdr.org/data/abstract-painting-art-wallpaper-hd-6.jpg);">
	<div class="absolute bg-black opacity-60 inset-0 z-0"></div>
	<div class="max-w-md w-full space-y-8 p-10 bg-white rounded-xl z-10">
        <div class="flex flex-col justify-center items-center relative">
            <!-- <div class="relative"> -->
            <img alt="..." src="https://cdn.discordapp.com/attachments/664629434573258763/854211798740107294/logo_landscape.png" class="align-middle absolute mb-24">
            <h2 class="mt-32 text-base font-bold text-gray-900">
				Input Email
			</h2>
			<p class="mt-2 text-sm text-center text-gray-600">Enter your email to change your password.</p>
        </div>
		<form class="mt-8 space-y-6" action="#" method="POST">
			<div class="relative">
				<label class="text-sm font-bold text-artiliser tracking-wide">Email</label>
				<input class="px-2 w-full text-base py-2 border rounded-lg border-artiliser focus:outline-none focus:border-artiliser" type="email" placeholder="Enter your Email" >
            </div>
			<div>
				<a href="/change-password" type="submit" class="w-full flex justify-center bg-artiliser text-white p-2.5 rounded-lg">
                    Next
                </a>
			</div>
		</form>
	</div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/backend/profile/input-email.blade.php ENDPATH**/ ?>