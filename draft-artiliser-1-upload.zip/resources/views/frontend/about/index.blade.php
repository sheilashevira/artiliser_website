@extends('layouts.userfrontend')
@section('content')
<div class="w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-10">
              <!-- About -->
              <div class="w-full  flex justify-center items-center">
                <img class="float-left object-cover w-32 md:w-52 lg:w-60 xl:w-72 shadow-sm" src="https://cdn.discordapp.com/attachments/664629434573258763/854211822747779072/logo.png" >
              </div>
              <div class="w-full border-b flex justify-center items-center">
                <div class="w-full mt-20 mb-20 md:mx-8 lg:mx-20 xl:mx-40  flex-col justify-center items-center">
                  <p class="text-center font-semibold text-gray-500" style="font-family: 'Montserrat', sans-serif;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore earum eaque quam possimus nihil laborum quo eligendi modi architecto vero. Distinctio beatae dolores nemo cumque ex suscipit magnam nam harum? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolores totam corrupti perspiciatis itaque accusantium adipisci quibusdam veniam nesciunt, neque nihil in esse labore ratione, qui fugiat? Quo neque dolore autem.</p>
                  <p class="text-center mt-6 font-semibold text-gray-500" style="font-family: 'Montserrat', sans-serif;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore earum eaque quam possimus nihil laborum quo eligendi modi architecto vero. Distinctio beatae dolores nemo cumque ex suscipit magnam nam harum? Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolores totam corrupti perspiciatis itaque accusantium adipisci quibusdam veniam nesciunt, neque nihil in esse labore ratione, qui fugiat? Quo neque dolore autem.</p>
                </div>
              </div>
            </div>
        </div>
    </div>
</div>
<div class="w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-10 mb-20">
            <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Contact Us</h1>
                <!-- Contact Us-->
                <div class="">
                    <form class="md:mx-32 lg:mx-60 xl:mx-96 space-y-6 px-8 " action="#" method="POST">
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Name" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Email" type="email" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Message" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-40 focus:placeholder-table focus:border-artiliser px-3 pb-28 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="relative flex justify-center items-center">
                        <a href="#" type="submit" class="w-32 h-10 hover-artiliserdark hover:bg-artiliserdark hover:text-white flex justify-center bg-artiliser text-white p-2 rounded-lg hover:text-white" style="font-family: 'Montserrat', sans-serif;">
                        Send
                        </a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-artiliser w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                <!-- Footer -->
                <div class="bottom-0 text-center">
                    <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection