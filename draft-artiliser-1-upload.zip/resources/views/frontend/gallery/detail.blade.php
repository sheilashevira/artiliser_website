@extends('layouts.userfrontend')
@section('content')
<link rel="stylesheet" href="{{ asset('css/selector3.css') }}">

<div id="detail">
    <div class="w-full lg:block hidden">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
            <div class="container mx-auto ">
                <div class=" grid mx-10 lg:mt-10">
                    <!-- Link -->
                    <div class="flex flex-row">
                        <a href="/gallery/detail" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Gallery</a>
                        <p class="text-sm font-semibold text-gray-400 mx-2" style="font-family: 'Montserrat', sans-serif;">/</p>
                        <a href="/gallery/abstract" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Abstract</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="w-full">
        <div class="max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row">
            <div class="container mx-auto ">
                <div class=" grid mx-10 mb-20">
                    <!-- Detail Image Desktop -->
                    <div class="mt-8 lg:mt-0 hidden md:block">
                        <div class="grid items-start grid-cols-1 md:grid-cols-2">
                            <div class="w-full md:pr-0">
                                <img class="float-left object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://s3-alpha-sig.figma.com/img/0f89/781c/65e31154f1ee7f73ed44c3ac86aa7ef6?Expires=1626048000&Signature=UoNy889SHQBraBn6txBMHCrf5wOLUbhgZGZ8sjfA62hrKAi9onJHEi6Vxd-WKgCxTKdvrzRca9WhFhOmGkveiUNemLP829KK3QwL5ZUR9vBwZ3raQbymXwwrLMGiXigx4M5iNDyaDowXznrz9D-56jodu8FWwXBFweo4sihw27q0KpA7u90KlyBvK4j8YPzQPNXdg5f1~QIt~rnfwt55NU-Gycw9kb7c6CLdrhHy49SrGZF181vQU567LzpOWUZoB18L5Le-W0qbWqfIyq-VsG9zsrP0qxhfrUmJchPQeGgBjDkaP6aOnRmuWGtjEy2D1Bob-rJhY10aiTarhKdWyQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA" >
                            </div>
                            <div class="mt-3 ml-0 lg:-ml-12 md:ml-8 md:mt-0">
                                <p class="float-center text-2xl md:text-2xl lg:text-4xl md:text-left text-center font-semibold tracking-tighter" style="color:#670067; font-family: 'Nunito', sans-serif;">
                                    The title of the name of the art and other paintings.
                                </p>
                                <div class="flex flex-row border-b justify-center items-center md:justify-start md:items-left">
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center leading-2 text-xs lg:text-sm font-bold" style="color:#6C656C; font-family: 'Montserrat', sans-serif;">
                                        Date Post
                                    </p>
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center text-gray-700 text-xs lg:text-sm leading-2 mx-2" style="font-family: 'Montserrat', sans-serif;">
                                        |
                                    </p>
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center text-gray-700 text-xs lg:text-sm leading-2" style="font-family: 'Montserrat', sans-serif;">
                                        Monday 05/07/2021
                                    </p>
                                </div>
                                <div class="flex flex-col">
                                    <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                    Choose Physical Or Digital Print :
                                    </label>
                                    <div class="type relative w-full lg:full mt-4" >
                                        <select placeholder="Choose a type" class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                            <option value="0">Choose a type</option>
                                            <option value="1">Type 1</option>
                                            <option value="2">Type 2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="flex flex-row">
                                    <div class="flex flex-col w-1/2 mr-1 ">
                                        <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                        Choose Art Size :
                                        </label>
                                        <div class=" relative w-full lg:full mt-4">
                                            <select placeholder="Choose a type" class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                                <option value="0">Choose a type</option>
                                                <option value="1">Type 1</option>
                                                <option value="2">Type 2</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="flex flex-col w-1/2 ml-1 ">
                                        <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                        Choose Printed Material :
                                        </label>
                                        <div class=" relative w-full lg:full mt-4">
                                            <select placeholder="Choose a type" class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                                <option value="0">Choose a type</option>
                                                <option value="1">Type 1</option>
                                                <option value="2">Type 2</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex flex-row ">
                                    <div class="flex flex-col w-1/2 lg:w-1/2 lg:mr-1 ">
                                        <p  class="mt-4 text-center md:text-left text-artiliser text-4xl lg:text-5xl " style="font-family: 'Montserrat'; font-weight:600;">
                                        $500
                                        </p>
                                    </div>
                                    <div class="flex flex-row w-full justify-center items-center  ">
                                        <div class="flex flex-col w-full mx-4">
                                            <a href="#" type="button" style="border-color:#670067; " class="mt-4 hover:bg-artiliser justify-center items-center hover:text-white text-artiliser border-artiliser rounded  text-center py-1 text-xs lg:text-base border-2 rounded-md shadow-sm">
                                                Add to Cart
                                            </a>
                                        </div>
                                        <div class="flex flex-col w-full ">
                                            <button onclick="myFunction3()" style="border-color:#670067; " class="mt-4 hover:bg-artiliserdark justify-center items-center hover:text-white text-white border-artiliser bg-artiliser rounded  text-center py-1 text-xs lg:text-base border-2 rounded-md shadow-sm">
                                                Buy Now
                                            </button>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Detail Image Mobile -->
                    <div class="mt-8 lg:mt-0 md:hidden block">
                        <div class="grid items-start grid-cols-1 md:grid-cols-2">
                            <div class="w-full md:pr-0">
                                <img class="float-left object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://s3-alpha-sig.figma.com/img/0f89/781c/65e31154f1ee7f73ed44c3ac86aa7ef6?Expires=1626048000&Signature=UoNy889SHQBraBn6txBMHCrf5wOLUbhgZGZ8sjfA62hrKAi9onJHEi6Vxd-WKgCxTKdvrzRca9WhFhOmGkveiUNemLP829KK3QwL5ZUR9vBwZ3raQbymXwwrLMGiXigx4M5iNDyaDowXznrz9D-56jodu8FWwXBFweo4sihw27q0KpA7u90KlyBvK4j8YPzQPNXdg5f1~QIt~rnfwt55NU-Gycw9kb7c6CLdrhHy49SrGZF181vQU567LzpOWUZoB18L5Le-W0qbWqfIyq-VsG9zsrP0qxhfrUmJchPQeGgBjDkaP6aOnRmuWGtjEy2D1Bob-rJhY10aiTarhKdWyQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA" >
                            </div>
                            <div class="mt-3 ml-0 lg:-ml-12 md:ml-8 md:mt-0">
                                <p class="float-center text-2xl md:text-2xl lg:text-4xl md:text-left text-center font-semibold tracking-tighter" style="color:#670067; font-family: 'Nunito', sans-serif;">
                                    The title of the name of the art and other paintings.
                                </p>
                                <div class="flex flex-row border-b justify-center items-center md:justify-start md:items-left">
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center leading-2 text-xs lg:text-sm font-bold" style="color:#6C656C; font-family: 'Montserrat', sans-serif;">
                                        Date Post
                                    </p>
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center text-gray-700 text-xs lg:text-sm leading-2 mx-2" style="font-family: 'Montserrat', sans-serif;">
                                        |
                                    </p>
                                    <p class=" float-right mt-6 mb-4 md:text-left text-center text-gray-700 text-xs lg:text-sm leading-2" style="font-family: 'Montserrat', sans-serif;">
                                        Monday 05/07/2021
                                    </p>
                                </div>
                                <div class="flex flex-col">
                                    <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                    Choose Physical Or Digital Print :
                                    </label>
                                    <div class=" relative w-full lg:full mt-4">
                                        <select placeholder="Choose a type" class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                            <option value="0">Choose a type</option>
                                            <option value="1">Type 1</option>
                                            <option value="2">Type 2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="flex flex-col">
                                    <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                    Choose Art Size :
                                    </label>
                                    <div class="type5 relative w-full lg:full mt-4">
                                        <select placeholder="Choose a type" class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                            <option value="0">Choose a type</option>
                                            <option value="1">Type 1</option>
                                            <option value="2">Type 2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="flex flex-col">
                                    <label  class="float-right mt-4 text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;">
                                    Choose Printed Material :
                                    </label>
                                    <div class="type6 relative w-full lg:full mt-4">
                                        <select placeholder="Choose a type"  class="px-3 w-full h-10 rounded-lg" style="color:#D3CCCC; background-color:#F5F6FA">
                                            <option value="0">Choose a type</option>
                                            <option value="1">Type 1</option>
                                            <option value="2">Type 2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="flex flex-col">
                                    <div class="flex flex-col w-full lg:w-1/2 lg:mr-1 justify-center items-center">
                                        <p  class="mt-8 text-center items-center md:text-left text-artiliser text-4xl lg:text-5xl" style="font-family: 'Montserrat'; font-weight:600;">
                                        $500
                                        </p>
                                    </div>
                                </div>
                                <div class="flex flex-row ">
                                    <div class="flex flex-row w-full justify-center items-center  ">
                                        <div class="flex flex-col w-full mx-4">
                                            <a href="#" type="button" style="border-color:#670067; " class="mt-4 hover:bg-artiliser justify-center items-center hover:text-white text-artiliser border-artiliser rounded md:px-2 lg:px-8 text-center py-1 text-xs lg:text-base border-2 rounded-md shadow-sm">
                                                Add to Cart
                                            </a>
                                        </div>
                                        <div class="flex flex-col w-full ">
                                            <button onclick="myFunction3()" style="border-color:#670067; " class="mt-4 hover:bg-artiliserdark justify-center items-center hover:text-white text-white border-artiliser bg-artiliser rounded md:px-2 lg:px-8 text-center py-1 text-xs lg:text-base border-2 rounded-md shadow-sm">
                                                Buy Now
                                            </button>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="w-full">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row">
            <div class="container mx-auto ">
                <div class=" grid mx-10 mb-20">
                    <!-- Description Title -->
                    <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Description</p>
                    <!-- Description -->
                    <p class="mt-6 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#706770; font-family:'Montserrat', sans-serif;">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloribus expedita saepe impedit doloremque quos mollitia molestias maiores, dolore optio autem, aut officiis. Laudantium quaerat illum dolores rerum quas minima eaque! Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius, eum nisi saepe ratione dolorem ullam veniam iure magnam aperiam dolore soluta iusto sunt, dolores mollitia ipsa corrupti optio perspiciatis natus. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maxime ipsa numquam cupiditate, amet, placeat adipisci debitis illum aperiam molestiae modi totam. Necessitatibus iure optio voluptatibus dolores possimus nemo voluptate. Pariatur.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- Types Desktop -->
    <div class="w-full md:block hidden">
        <div class="  max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row">
            <div class="container mx-auto ">
                <div class="border rounded-lg grid mx-10 mb-20" style="background-color:#F3E5F3; border-color:#CEA4CE">
                    <!-- Types Desktop -->
                    <div class="flex flex-row px-4 py-8">
                        <div class="flex flex-col mx-3">
                            <!-- Types 1 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Physical Print</p>
                            <!-- Description -->
                            <p class="mt-6 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum eaque nam earum aliquam odio debitis non est ut, numquam, natus ipsa. Quibusdam dolore tenetur tempora soluta cum? Illum, nisi repudiandae?
                            </p>
                        </div>
                        <div class="flex flex-col mx-3">
                            <!-- Types 2 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Digital Print</p>
                            <!-- Description -->
                            <p class="mt-6 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fugiat adipisci facere fugit voluptas recusandae dolorem non quos, quis dolor accusantium. Est in iusto neque laudantium officiis exercitationem, illum nam? Necessitatibus.
                            </p>
                        </div>
                        <div class="flex flex-col mx-3 ">
                            <!-- Types 3 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Material Print</p>
                            <!-- Description -->
                            <p class="mt-6 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Minima mollitia commodi adipisci illum quidem exercitationem rerum, temporibus ut perferendis earum qui ratione dolorum, expedita quis, eos consequuntur nam impedit? Dolores?
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Types Mobile -->
    <div class="w-full md:hidden block">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row">
            <div class="container mx-auto ">
                <div class=" rounded-lg grid mx-10 mb-10" style="background-color:#F3E5F3; border-color:#CEA4CE">
                    <!-- Types Mobile -->
                    <div class="flex flex-col px-4 py-8">
                        <div class="flex flex-col mx-1 mr-3">
                            <!-- Types 1 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Physical Print</p>
                            <!-- Description -->
                            <p class="mt-2 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum eaque nam earum aliquam odio debitis non est ut, numquam, natus ipsa. Quibusdam dolore tenetur tempora soluta cum? Illum, nisi repudiandae?
                            </p>
                        </div>
                        <div class="flex flex-col mx-1 mr-3 mt-4">
                            <!-- Types 2 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Digital Print</p>
                            <!-- Description -->
                            <p class="mt-2 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fugiat adipisci facere fugit voluptas recusandae dolorem non quos, quis dolor accusantium. Est in iusto neque laudantium officiis exercitationem, illum nam? Necessitatibus.
                            </p>
                        </div>
                        <div class="flex flex-col mx-1 mr-3 mt-4">
                            <!-- Types 3 -->
                            <p class="text-left md:text-left text-artiliser text-xs lg:text-sm font-extrabold lg:block xl:block leading-2" style="font-family: 'Nunito', sans-serif;" style="color:#670067; font-family:Asap; font-weight:1000">Material Print</p>
                            <!-- Description -->
                            <p class="mt-2 text-left md:text-left text-xs lg:text-sm  lg:block xl:block leading-2" style="color:#9B8F9B; font-family:'Montserrat', sans-serif;">
                                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Minima mollitia commodi adipisci illum quidem exercitationem rerum, temporibus ut perferendis earum qui ratione dolorum, expedita quis, eos consequuntur nam impedit? Dolores?
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="  w-full bg-artiliserthin">
    <div class=" max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
        <div class=" container mx-auto">
            <div class="grid mx-10 mt-10 mb-20">
                <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Similar Art</h1>
                <!-- Photo Grid Card 1-->
                <div class="container md:mx-auto " x-data="loadGallery()">
                    <div class="box-wrapper flex flex-row flex justify-center items-center ml-4 hidden">
                        <div class=" bg-white rounded-lg flex items-center w-32 md:w-80 lg:w-96 p-3 shadow-lg border border-gray-200" style="font-family: 'Montserrat', sans-serif;">
                        <button @click="getImages()" class="outline-none focus:outline-none">
                            <svg class=" w-4 md:w-5 text-gray-600 h-4 md:h-5 cursor-pointer" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24">
                                <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </button>
                        <input x-ref="searchField" x-model="search" x-on:click="viewPage(0)" x-on:keydown.window.prevent.slash=" viewPage(0), $refs.searchField.focus()" placeholder="Search..." type="search" class="w-full pl-4 text-sm outline-none focus:outline-none bg-transparent">
                        </div>
                        <div class=" bg-white rounded-lg flex items-center w-28 md:w-28 lg:w-32 p-3 shadow-lg border border-gray-200 mx-4" style="font-family: 'Montserrat', sans-serif;">
                        <div class="select">
                            <select name="" id="" class="text-xs md:text-sm outline-none focus:outline-none bg-transparent">
                                <option value="filterby" selected>Filter By</option>
                                <option value="category 1">Category 1</option>
                                <option value="category 2">Category 2</option>
                                <option value="category 3">Category 3</option>
                                </select>
                        </div>  
                        </div>
                    </div>
                    <div class=" grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 grid-rows-1 gap-4 ">
                        <template x-for="item in filteredGallery" :key="item" class="items-center container mx-auto my-auto">
                        <div class="lg:flex-col items-center container mx-auto my-auto hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                            <div class="flex items-center justify-center">
                            <img :src="`${item.image}`" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:full md:h-72 w-full h-52 overflow-hidden rounded-3xl">
                            </div>
                            <div class="flex md:items-left items-center md:justify-start justify-center">
                            <div class="p-4">
                                <p x-text="item.title" class=" text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;"></p>
                                <p x-text="item.content" class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;"></p>
                                <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0">
                                <a href="/gallery/detail" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser " style="font-family: 'Montserrat', sans-serif;">Read More</a>
                                </div>
                            </div>
                            </div>
                        </div>
                        </template>
                    </div>
                </div>
        </div>
        </div>
    </div>
    </div>
    <div class="w-full">
        <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
            <div class="container mx-auto">
                <div class="grid mx-10 mt-10 mb-20">
                <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Contact Us</h1>
                    <!-- Contact Us-->
                    <div class="">
                        <form class="md:mx-32 lg:mx-60 xl:mx-96 space-y-6 px-8 " action="#" method="POST">
                            <div class="py-0 ">
                                <div class="relative ">
                                    <input placeholder="Put Your Name" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                                </div>
                            </div>
                            <div class="py-0 ">
                                <div class="relative ">
                                    <input placeholder="Put Your Email" type="email" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                                </div>
                            </div>
                            <div class="py-0 ">
                                <div class="relative ">
                                    <input placeholder="Put Your Message" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-40 focus:placeholder-table focus:border-artiliser px-3 pb-28 text-md" style="font-family: 'Montserrat', sans-serif;">
                                </div>
                            </div>
                            <div class="relative flex justify-center items-center">
                                <a href="#" type="submit" class="w-32 h-10 hover-artiliserdark hover:bg-artiliserdark hover:text-white flex justify-center bg-artiliser text-white p-2 rounded-lg hover:text-white" style="font-family: 'Montserrat', sans-serif;">
                                Send
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-artiliser w-full">
        <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
            <div class="container mx-auto">
                <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                    <!-- Footer -->
                    <div class="bottom-0 text-center">
                        <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="checkout" class="hidden">
    <div class="w-full bg-white">
    <div class="max-w-screen-xl px-4 py-4 mx-auto font-medium lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class=" container mx-auto">
        <div class="grid mx-4  lg:mt-10">
            <!-- Cart -->
            <div class=" flex flex-row justify-center">
                <div class=" flex flex-col w-full">
                    <h1 class="text-2xl text-center md:text-5xl mb-8" style="color:#670067; font-family:'Asap';">Your Cart</h1>
                    <p class="text-sm text-center md-text-base mb-10" style="color:#6C656C; font-family:'Montserrat', sans-serrif;">Make sure the data you entered is correct.</p>
                </div>
                <div class=" flex flex-col items-right">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 md:h-10 md:w-10 " style="color:#645A5A" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </div>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div class="w-full bg-white lg:block hidden">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
            <div class="container mx-auto ">
                <div class=" grid mx-10">
                    <!-- Link -->
                    <div class="flex flex-row">
                        <a href="/gallery/detail" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Home</a>
                        <p class="text-sm font-semibold text-gray-400 mx-2" style="font-family: 'Montserrat', sans-serif;">/</p>
                        <a href="/gallery/abstract" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Cart Checkout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Desktop -->
    <div class="w-full bg-white lg:block hidden">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
            <div class="container mx-auto ">
                <div class=" grid mx-10">
                    <!-- Link -->
                    <div class="flex flex-row w-full">
                        <!-- Bagian Kiri -->
                        <div class="flex flex-col w-full ">
                            <h1 class="text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Your Items</h1>
                            <div class="flex flex-row  mb-10">
                                <img class="float-left object-cover w-28 h-24 shadow-sm rounded-xl mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                                <div class="flex flex-col w-1/2 mr-4">
                                    <h1 class=" text-md text-center font-medium md:text-normal md:text-left" style="color:#504A50; font-family:'Asap';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="mt-2 text-left text-lg md:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                        $500
                                    </p>
                                </div>
                                <div class=" flex flex-col w-full mr-2 justify-center items-center">
                                    <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%; ">
                                        <option>Physical Print</option>
                                        <option>Type 1</option>
                                    </select>
                                    <div class="flex flex-row w-full mt-4 ">
                                        <div class="mr-2 w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option>100x200cm</option>
                                                <option>Type 1</option>
                                            </select>
                                        </div>
                                        <div class="ml-2 w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option>Canvas</option>
                                                <option>Type 1</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex flex-col justify-center items-center">
                                    <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="flex flex-row mb-10">
                                <img class="float-left object-cover w-28 h-24 shadow-sm  rounded-xl mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                                <div class="flex flex-col w-1/2 mr-4">
                                    <h1 class=" text-md text-center font-medium md:text-normal md:text-left" style="color:#504A50; font-family:'Asap';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="mt-2 text-left text-lg md:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                        $350
                                    </p>
                                </div>
                                <div class="typeprint flex flex-col w-full mr-2 justify-center items-center">
                                    <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%; ">
                                        <option>Digital Print</option>
                                        <option>Type 1</option>
                                    </select>
                                </div>
                                <div class="flex flex-col justify-center items-center">
                                    <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="border mr-8 mb-10" style="color:#F0EAEA;"></div>
                            <h1 class="mt-10text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Shipping Details</h1>
                            <div id="div1" class=" border rounded-lg grid mr-8 mb-20" style="background-color:#FBF0F0; border-color:#EF9BEF">
                                <div class="flex flex-row w-full">
                                    <!-- Icon -->
                                    <div class="px-4 py-4 text-artiliser">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <!-- Nama dan Alamat -->
                                    <div class="flex flex-col py-4 w-full">
                                        <h1 class=" text-sm md:text-md text-center font-semibold md:text-left" style="color:#656363;  font-family:'Asap';">
                                            Daniel Radcliffe
                                        </h1>
                                        <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Ingram Road, North Wilkesboro, NC 28659,North
                                        </p>
                                        <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Wilkesboro,United States, 4211 |
                                        </p>
                                        <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Daniel@youremail.com
                                        </p>
                                    </div>
                                    <!-- Button Edit -->
                                    <div class="px-4 py-4 text-artiliser" >
                                        <button class="font-bold text-artiliser hover:text-artiliserdark focus:text-artiliserdark" onclick="myFunction()">Edit</button>
                                    </div>
                                </div>
                            </div>
                            <div id="div2" class="flex flex-col hidden">
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Full Name</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="Daniel Radcliffe" placeholder="Input Full Name" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Address</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="Ingram Road" placeholder="Input Address" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Address II</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="North Wilkesboro, NC 28659" placeholder="Input Address II" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">City</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <select id="city1" class="select2 req_place w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" data-select-search="true" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                        <option>North Wilkesboro</option>
                                        <option>City 1</option>
                                    </select>
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Country</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <select id="country1" class="select2 req_place w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" data-select-search="true" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                        <option>United States</option>
                                        <option>Country 1</option>
                                    </select>
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Zip Code</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="4211" placeholder="Input Zip Code" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Email Address</span>
                                <div class="relative w-full lg:w-3/5 mb-10">
                                    <input value="Daniel@youremail.com" placeholder="Input Email Address" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                            </div>
                        </div>
                        <!-- Bagian Kanan -->
                        <div class="flex flex-col w-1/2">
                            <div class="border rounded-lg grid ml-10 mb-6" style="background-color:#FCFCFC; border-color:#E9CFE9">
                                <div class="flex flex-col w-full">
                                    <!-- Title -->
                                    <div class="px-4 py-4 text-artiliser">
                                        <h1 class=" text-sm md:text-md text-center font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                            Cost Information
                                        </h1>
                                    </div>
                                    <!-- Content -->
                                    <div class="flex flex-row px-4 mb-4">
                                        <h1 class=" text-xs md:text-sm text-center md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            The title of the name of the art and other paintings. 2
                                        </h1>
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $350
                                        </p>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4">
                                        <h1 class=" text-xs md:text-sm text-center md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            The title of the name of the art and other paintings.
                                        </h1>
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $500
                                        </p>
                                    </div>
                                    <div class="border-b mx-4 mb-4" style="border-color:#F0EAEA"></div>
                                    <!-- Title -->
                                    <div class="px-4 pb-4 text-artiliser">
                                        <h1 class=" text-sm md:text-md text-center font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                            Cost Information
                                        </h1>
                                    </div>
                                    <!-- Content -->
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Courier
                                            </h1>
                                            <p class="text-xs text-center md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                                JNT Express
                                            </p>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                                $350
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Tax
                                            </h1>
                                            <p class="text-xs text-center md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                                Country 20%
                                            </p>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                                $200
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Total price
                                            </h1>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-md md:text-xl font-bold text-center  md:text-left" style="color:#5F82C5;  font-family: 'Montserrat';">
                                                $1,200
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-row ml-10 mb-20 text-center">
                                <div class="border-2 text-sm rounded-lg w-1/2 mr-2 py-1 border-artiliser text-artiliser hover:text-white hover:bg-artiliser">
                                    <a href="#" type="button" class="">Cancel</a>
                                </div>
                                <div class="border-2 text-sm rounded-lg w-1/2 ml-2 py-1 bg-artiliser border-artiliser text-white hover:text-white hover:bg-artiliserdark">
                                    <button class="modal-open">Checkout</button>
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile -->
    <div class="w-full bg-white block lg:hidden">
        <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
            <div class="container mx-auto ">
                <div class=" grid mx-5 sm:mx-10">
                    <!-- Link -->
                    <div class="flex flex-col lg:flex-row w-full">
                        <!-- Bagian Kiri -->
                        <div class="flex flex-col w-full ">
                            <h1 class="text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Your Items</h1>
                            <div class="flex flex-row mb-4 lg:mb-10">
                                <img class="float-left object-cover w-24 h-20 lg:w-28 lg:h-24 shadow-sm rounded-xl mr-4 lg:mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                                <div class="flex flex-col w-full mr-8">
                                    <h1 class=" text-xs md:text-lg lg:text-md text-left font-medium md:text-normal lg:text-left" style="color:#504A50; font-family:'Asap';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="mt-2 text-left text-lg md:text-2xl lg:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                        $500
                                    </p>
                                </div>
                                <div class="flex flex-col ">
                                    <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="relative flex flex-row mb-10 mr-6 w-full">
                                <div class="typeprint flex flex-col w-full  justify-center items-center">
                                    <div class="flex flex-col relative h-full w-full">
                                        <div class="relative w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option value="0">United States Minor Outlying Islands</option>
                                                <option value="1">Type 1</option>
                                                <option value="2">Type 2</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="flex flex-row relative w-full mt-4 ">
                                        <div class="relative w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option value="0">100x200cm</option>
                                                <option value="1">Type 1</option>
                                                <option value="2">Type 2</option>
                                            </select>
                                        </div>
                                        <div class=" ml-2 relative w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option value="0">Canvas</option>
                                                <option value="1">Type 1</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-row mb-4 lg:mb-10">
                                <img class="float-left object-cover w-24 h-20 lg:w-28 lg:h-24 shadow-sm rounded-xl mr-4 lg:mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                                <div class="flex flex-col w-full mr-8">
                                    <h1 class=" text-xs md:text-lg lg:text-md text-left font-medium md:text-normal lg:text-left" style="color:#504A50; font-family:'Asap';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="mt-2 text-left text-lg md:text-2xl lg:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                        $350
                                    </p>
                                </div>
                                <div class="flex flex-col ">
                                    <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div class="flex flex-row mb-10">
                                <div class="typeprint flex flex-col w-full justify-center items-center">
                                    <div class="flex flex-col relative h-full w-full">
                                        <div class=" relative w-full">
                                            <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif; width: 100%;">
                                                <option value="0">Digital Print</option>
                                                <option value="1">Type 1</option>
                                                <option value="2">Type 2</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="border mb-10" style="color:#F0EAEA;"></div>
                            <h1 class="text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Shipping Details</h1>
                            <div id="div3" class="border rounded-lg grid mb-10" style="background-color:#FBF0F0; border-color:#EF9BEF">
                                <div class="flex flex-row w-full">
                                    <!-- Icon -->
                                    <div class="px-4 py-4 text-artiliser">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                        </svg>
                                    </div>
                                    <!-- Nama dan Alamat -->
                                    <div class="flex flex-col py-4 w-full">
                                        <h1 class=" text-sm md:text-md text-left font-semibold md:text-left" style="color:#656363;  font-family:'Asap';">
                                            Daniel Radcliffe
                                        </h1>
                                        <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Ingram Road, North Wilkesboro, NC 28659,North
                                        </p>
                                        <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Wilkesboro,United States, 4211 |
                                        </p>
                                        <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                            Daniel@youremail.com
                                        </p>
                                    </div>
                                    <!-- Button Edit -->
                                    <div class="px-4 py-4 text-artiliser">
                                        <button onclick="myFunction2()" class="font-bold text-artiliser hover:text-artiliserdark focus:text-artiliserdark">Edit</button>
                                    </div>
                                </div>
                            </div>
                            <div id="div4" class="flex flex-col hidden">
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Full Name</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="Daniel Radcliffe" placeholder="Input Full Name" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Address</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="Ingram Road" placeholder="Input Address" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Address II</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="North Wilkesboro, NC 28659" placeholder="Input Address II" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">City</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <select  placeholder="Input City" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight">
                                        <option>North Wilkesboro</option>
                                    </select>
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Country</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <select  placeholder="Input Country" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight">
                                        <option>United States</option>
                                    </select>
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Zip Code</span>
                                <div class="relative w-full lg:w-3/5 mb-4">
                                    <input value="4211" placeholder="Input Zip Code" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                                <span class="text-sm lg:text-md text-artiliser font-bold mb-2 lg:mr-3 " style="font-family:'Nunito'">Email Address</span>
                                <div class="relative w-full lg:w-3/5 mb-10">
                                    <input value="Daniel@youremail.com" placeholder="Input Email Address" style="background-color:#F5F6FA; color:#6D6969; font-family:'Nunito'" class="text-md px-3 py-2 w-full placeholder-gray-400 focus:placeholder-gray-500 focus:bg-artiliserlight"> 
                                </div>
                            </div>
                        </div>
                        <!-- Bagian Kanan -->
                        <div class="flex flex-col w-full">
                            <div class="border rounded-lg grid mb-6" style="background-color:#FCFCFC; border-color:#E9CFE9">
                                <div class="flex flex-col w-full">
                                    <!-- Title -->
                                    <div class="px-4 py-4 text-artiliser">
                                        <h1 class=" text-sm md:text-md text-left font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                            Cost Information
                                        </h1>
                                    </div>
                                    <!-- Content -->
                                    <div class="flex flex-row px-4 mb-4">
                                        <h1 class=" text-xs md:text-sm text-left md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            The title of the name of the art and other paintings. 2
                                        </h1>
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $350
                                        </p>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4">
                                        <h1 class=" text-xs md:text-sm text-left md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            The title of the name of the art and other paintings.
                                        </h1>
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $500
                                        </p>
                                    </div>
                                    <div class="border-b mx-4 mb-4" style="border-color:#F0EAEA"></div>
                                    <!-- Title -->
                                    <div class="px-4 pb-4 text-artiliser">
                                        <h1 class=" text-sm md:text-md text-left font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                            Cost Information
                                        </h1>
                                    </div>
                                    <!-- Content -->
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-cleftenter font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Courier
                                            </h1>
                                            <p class="text-xs text-left md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                                JNT Express
                                            </p>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                                $350
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-left font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Tax
                                            </h1>
                                            <p class="text-xs text-left md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                                Country 20%
                                            </p>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                                $200
                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex flex-row px-4 mb-4 ">
                                        <div class="flex flex-col w-full">
                                            <h1 class=" text-xs md:text-sm text-left font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                                Total price
                                            </h1>
                                        </div>
                                        <div class="flex justify-center items-center">
                                            <p class="text-md md:text-xl font-bold text-center  md:text-left" style="color:#5F82C5;  font-family: 'Montserrat';">
                                                $1,200
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex flex-row mb-20 text-center">
                                <div class="border-2 text-sm rounded-lg w-1/2 mr-2 py-1 border-artiliser text-artiliser hover:text-white hover:bg-artiliser">
                                    <a href="#" type="button" class="">Cancel</a>
                                </div>
                                <div class="border-2 text-sm rounded-lg w-1/2 ml-2 py-1 bg-artiliser border-artiliser text-white hover:text-white hover:bg-artiliserdark">
                                    <button class="modal-open">Checkout</button>
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-artiliser w-full">
        <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
            <div class="container mx-auto">
                <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                    <!-- Footer -->
                    <div class="bottom-0 text-center">
                        <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Modal-->
<div class="modal opacity-0 pointer-events-none fixed w-full h-full top-0 left-0 flex items-center justify-center">
    <div class="modal-overlay absolute w-full h-full bg-gray-900 opacity-50"></div>
    
    <div class="modal-container bg-white w-11/12 md:max-w-md mx-auto rounded shadow-lg z-50 overflow-y-auto">
      
      <div class="modal-close absolute top-0 right-0 cursor-pointer flex flex-col items-center mt-4 mr-4 text-white text-sm z-50">
        <svg class="fill-current text-white" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
          <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"></path>
        </svg>
        <span class="text-sm">(Esc)</span>
      </div>

      <!-- Add margin if you want to see some of the overlay behind the modal-->
      <div class="modal-content py-4 text-left px-6">
        <!--Title-->
        <div class="flex justify-between items-center pb-3">
          <p class="text-2xl font-bold">Payment</p>
          <div class="modal-close cursor-pointer z-50">
            <svg class="fill-current text-black" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18">
              <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"></path>
            </svg>
          </div>
        </div>

        <!--Body-->
        <div id="paypal-button-container"></div>
            <div class="flex justify-center items-center">
                <script
                    src="https://www.paypal.com/sdk/js?client-id=AVL4XnsNLQHS2ZNeIv6AiN7p1WTWHNYbx6CxJBEyaNzyjH4n9Jb6u6Bq_pJbrmVADdL9oIqnXax30Vux"> // Required. Replace YOUR_CLIENT_ID with your sandbox client ID.
                </script>
            </div>
        </div>

        <!--Footer-->
        <div class="flex justify-end pt-2 px-6 bg-gray-100">
            <div class="flex flex-col w-full">
                <h1 class=" text-xs md:text-base text-left font-extrabold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                    Total price
                </h1>
            </div>
            <div class="flex justify-center items-center">
                <p class="text-md md:text-xl font-bold text-center  md:text-left" style="color:#5F82C5;  font-family: 'Montserrat';">
                    $1,200
                </p>
            </div>
        </div>
      </div>
    </div>
  </div>

  <script>
  paypal.Buttons({
    createOrder: function(data, actions) {
      // This function sets up the details of the transaction, including the amount and line item details.
      return actions.order.create({
        purchase_units: [{
          amount: {
            value: '0.01'
          }
        }]
      });
    }
  }).render('#paypal-button-container');
</script>
<script>
      var sourceData = [
        {
          id: "1",
          title: "Sheila Shevira..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "2",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "3",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
      ];
      function loadGallery() {
        return {
          search: "",
          pageNumber: 0,
          size: 3,
          total: "",
          myForData: sourceData,

          get filteredGallery() {
            const start = this.pageNumber * this.size,
              end = start + this.size;

            if (this.search === "") {
              this.total = this.myForData.length;
              return this.myForData.slice(start, end);
            }

            //Return the total results of the filters
            this.total = this.myForData.filter((item) => {
              return item.title
                .toLowerCase()
                .includes(this.search.toLowerCase());
            }).length;

            //Return the filtered data
            return this.myForData
              .filter((item) => {
                return item.title
                  .toLowerCase()
                  .includes(this.search.toLowerCase());
              })
              .slice(start, end);
          },
        };
      }
</script>

<!-- Dropdown Search JS -->
<script>
  $(document).ready(function(){
  
    // Initialize select2
    $("#city1").select2();

    // Read selected option
    $('#but_read').click(function(){
      var username = $('#city1 option:selected').text();
      var userid = $('#city1').val();

      $('#result').html("id : " + userid + ", name : " + username);

    });
  });

  $(document).ready(function(){
  
    // Initialize select2
    $("#country1").select2();

    // Read selected option
    $('#but_read').click(function(){
      var username = $('#country1 option:selected').text();
      var userid = $('#country1').val();

      $('#result').html("id : " + userid + ", name : " + username);

    });
  });

  $(document).ready(function(){
  
    // Initialize select2
    $("#city2").select2();

    // Read selected option
    $('#but_read').click(function(){
      var username = $('#city2 option:selected').text();
      var userid = $('#city2').val();

      $('#result').html("id : " + userid + ", name : " + username);

    });
  });

  $(document).ready(function(){
  
    // Initialize select2
    $("#country2").select2();

    // Read selected option
    $('#but_read').click(function(){
        var username = $('#country2 option:selected').text();
        var userid = $('#country2').val();

        $('#result').html("id : " + userid + ", name : " + username);

    });
  });
</script>

<script>
    function myFunction() {
        var x = document.getElementById("div1");
        var y = document.getElementById("div2");

        if(y.style.display === "none"){
            x.style.display = "block";
            y.style.display = "none";
        }else {
            x.style.display = "none";
            y.style.display = "block";
        }
    }

    function myFunction2() {
        var x = document.getElementById("div3");
        var y = document.getElementById("div4");

        if(y.style.display === "none"){
            x.style.display = "block";
            y.style.display = "none";
        }else {
            x.style.display = "none";
            y.style.display = "block";
        }
    }

    function myFunction3() {
        var x = document.getElementById("detail");
        var y = document.getElementById("checkout");

        if(y.style.display === "none"){
            x.style.display = "block";
            y.style.display = "none";
        }else {
            x.style.display = "none";
            y.style.display = "block";
        }
    }
</script>

<style>
    .modal {
      transition: opacity 0.25s ease;
    }
    body.modal-active {
      overflow-x: hidden;
      overflow-y: visible !important;
    }
</style>

<script>
    var openmodal = document.querySelectorAll('.modal-open')
    for (var i = 0; i < openmodal.length; i++) {
      openmodal[i].addEventListener('click', function(event){
    	event.preventDefault()
    	toggleModal()
      })
    }
    
    const overlay = document.querySelector('.modal-overlay')
    overlay.addEventListener('click', toggleModal)
    
    var closemodal = document.querySelectorAll('.modal-close')
    for (var i = 0; i < closemodal.length; i++) {
      closemodal[i].addEventListener('click', toggleModal)
    }
    
    document.onkeydown = function(evt) {
      evt = evt || window.event
      var isEscape = false
      if ("key" in evt) {
    	isEscape = (evt.key === "Escape" || evt.key === "Esc")
      } else {
    	isEscape = (evt.keyCode === 27)
      }
      if (isEscape && document.body.classList.contains('modal-active')) {
    	toggleModal()
      }
    };
    function toggleModal () {
      const body = document.querySelector('body')
      const modal = document.querySelector('.modal')
      modal.classList.toggle('opacity-0')
      modal.classList.toggle('pointer-events-none')
      body.classList.toggle('modal-active')
    }
</script>
@endsection