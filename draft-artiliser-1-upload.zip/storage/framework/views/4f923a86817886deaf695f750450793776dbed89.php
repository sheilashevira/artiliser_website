
<?php $__env->startSection('content'); ?>
<div class="w-full bg-white">
  <div class="max-w-screen-xl px-4 py-4 mx-auto font-medium lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
    <div class=" container mx-auto">
      <div class="grid mx-4  lg:mt-10">
        <!-- Cart -->
        <div class=" flex flex-row justify-center">
            <div class=" flex flex-col w-full">
                <h1 class="text-2xl text-center md:text-5xl mb-8" style="color:#670067; font-family:'Asap';">Your Cart</h1>
                <p class="text-sm text-center md-text-base mb-10" style="color:#6C656C; font-family:'Montserrat', sans-serrif;">Make sure the data you entered is correct.</p>
            </div>
            <div class=" flex flex-col items-right">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 md:h-10 md:w-10 " style="color:#645A5A" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w-full bg-white">
    <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
        <div class="container mx-auto ">
            <div class=" grid mx-10">
                <!-- Link -->
                <div class="flex flex-row">
                    <a href="/gallery/detail" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Home</a>
                    <p class="text-sm font-semibold text-gray-400 mx-2" style="font-family: 'Montserrat', sans-serif;">/</p>
                    <a href="/gallery/abstract" class="text-sm font-semibold text-gray-400 hover:text-artiliser focus:text-artiliser" style="font-family: 'Montserrat', sans-serif;">Cart Checkout</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="w-full bg-white lg:block hidden">
    <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
        <div class="container mx-auto ">
            <div class=" grid mx-10">
                <!-- Link -->
                <div class="flex flex-row w-full">
                    <!-- Bagian Kiri -->
                    <div class="flex flex-col w-full ">
                        <h1 class="text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Your Items</h1>
                        <div class="flex flex-row  mb-10">
                            <img class="float-left object-cover w-28 h-24 shadow-sm rounded-xl mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                            <div class="flex flex-col w-1/2 mr-4">
                                <h1 class=" text-md text-center font-medium md:text-normal md:text-left" style="color:#504A50; font-family:'Asap';">
                                    The title of the name of the art and other paintings.
                                </h1>
                                <p class="mt-2 text-left text-lg md:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                    $500
                                </p>
                            </div>
                            <div class="flex flex-col w-full mr-2 justify-center items-center">
                                <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                    <option>Physical Print</option>
                                    <option>Type 1</option>
                                </select>
                                <div class="flex flex-row w-full mt-4">
                                    <select class="mr-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>100x200cm</option>
                                        <option>Type 1</option>
                                    </select>
                                    <select class="ml-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>Canvas</option>
                                        <option>Type 1</option>
                                    </select>
                                </div>
                            </div>
                            <div class="flex flex-col justify-center items-center">
                                <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div class="flex flex-row mb-10">
                            <img class="float-left object-cover w-28 h-24 shadow-sm  rounded-xl mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                            <div class="flex flex-col w-1/2 mr-4">
                                <h1 class=" text-md text-center font-medium md:text-normal md:text-left" style="color:#504A50; font-family:'Asap';">
                                    The title of the name of the art and other paintings.
                                </h1>
                                <p class="mt-2 text-left text-lg md:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                    $350
                                </p>
                            </div>
                            <div class="flex flex-col w-full mr-2 justify-center items-center">
                                <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                    <option>Physical Print</option>
                                    <option>Type 1</option>
                                </select>
                            </div>
                            <div class="flex flex-col justify-center items-center">
                                <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div class="border mr-8 mb-10" style="color:#F0EAEA;"></div>
                        <h1 class="mt-10text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Shipping Details</h1>
                        <div class="border rounded-lg grid mr-8 mb-20" style="background-color:#FBF0F0; border-color:#EF9BEF">
                            <div class="flex flex-row w-full">
                                <!-- Icon -->
                                <div class="px-4 py-4 text-artiliser">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <!-- Nama dan Alamat -->
                                <div class="flex flex-col py-4 w-full">
                                    <h1 class=" text-sm md:text-md text-center font-semibold md:text-left" style="color:#656363;  font-family:'Asap';">
                                        Daniel Radcliffe
                                    </h1>
                                    <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Ingram Road, North Wilkesboro, NC 28659,North
                                    </p>
                                    <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Wilkesboro,United States, 4211 |
                                    </p>
                                    <p class="text-sm md:text-md text-center  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Daniel@youremail.com
                                    </p>
                                </div>
                                <!-- Button Edit -->
                                <div class="px-4 py-4 text-artiliser">
                                    <a href="#" type="button" class="font-bold text-artiliser hover:text-artiliserdark focus:text-artiliserdark">Edit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Bagian Kanan -->
                    <div class="flex flex-col w-1/2">
                        <div class="border rounded-lg grid ml-10 mb-6" style="background-color:#FCFCFC; border-color:#E9CFE9">
                            <div class="flex flex-col w-full">
                                <!-- Title -->
                                <div class="px-4 py-4 text-artiliser">
                                    <h1 class=" text-sm md:text-md text-center font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                        Cost Information
                                    </h1>
                                </div>
                                <!-- Content -->
                                <div class="flex flex-row px-4 mb-4">
                                    <h1 class=" text-xs md:text-sm text-center md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                        The title of the name of the art and other paintings. 2
                                    </h1>
                                    <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                        $350
                                    </p>
                                </div>
                                <div class="flex flex-row px-4 mb-4">
                                    <h1 class=" text-xs md:text-sm text-center md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                        $500
                                    </p>
                                </div>
                                <div class="border-b mx-4 mb-4" style="border-color:#F0EAEA"></div>
                                <!-- Title -->
                                <div class="px-4 text-artiliser">
                                    <h1 class=" text-sm md:text-md text-center font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                        Cost Information
                                    </h1>
                                </div>
                                <!-- Content -->
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Courier
                                        </h1>
                                        <p class="text-xs text-center md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                            JNT Express
                                        </p>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $350
                                        </p>
                                    </div>
                                </div>
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Tax
                                        </h1>
                                        <p class="text-xs text-center md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                            Country 20%
                                        </p>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $200
                                        </p>
                                    </div>
                                </div>
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-center font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Total price
                                        </h1>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-md md:text-xl font-bold text-center  md:text-left" style="color:#5F82C5;  font-family: 'Montserrat';">
                                            $1,200
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-row ml-10 mb-20 text-center">
                            <div class="border-2 text-sm rounded-lg w-1/2 mr-2 py-1 border-artiliser text-artiliser hover:text-white hover:bg-artiliser">
                                <a href="#" type="button" class="">Cancel</a>
                            </div>
                            <div class="border-2 text-sm rounded-lg w-1/2 ml-2 py-1 bg-artiliser border-artiliser text-white hover:text-white hover:bg-artiliserdark">
                                <a href="#" type="button" class="">Checkout</a>
                            </div>
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="w-full bg-white block lg:hidden">
    <div class=" max-w-screen-xl px-0 lg:px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row ">
        <div class="container mx-auto ">
            <div class=" grid mx-5 sm:mx-10">
                <!-- Link -->
                <div class="flex flex-col lg:flex-row w-full">
                    <!-- Bagian Kiri -->
                    <div class="flex flex-col w-full ">
                        <h1 class="text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Your Items</h1>
                        <div class="flex flex-row mb-4 lg:mb-10">
                            <img class="float-left object-cover w-24 h-20 lg:w-28 lg:h-24 shadow-sm rounded-xl mr-4 lg:mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                            <div class="flex flex-col w-full mr-8">
                                <h1 class=" text-xs md:text-lg lg:text-md text-left font-medium md:text-normal lg:text-left" style="color:#504A50; font-family:'Asap';">
                                    The title of the name of the art and other paintings.
                                </h1>
                                <p class="mt-2 text-left text-lg md:text-2xl lg:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                    $500
                                </p>
                            </div>
                            <div class="flex flex-col ">
                                <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div class="flex flex-row mb-10 mr-6">
                            <div class="flex flex-col w-full mr-2 justify-center items-center">
                                <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                    <option>Physical Print</option>
                                    <option>Type 1</option>
                                </select>
                                <div class="flex flex-row w-full mt-4">
                                    <select class="mr-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>100x200cm</option>
                                        <option>Type 1</option>
                                    </select>
                                    <select class="ml-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>Canvas</option>
                                        <option>Type 1</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-row mb-4 lg:mb-10">
                            <img class="float-left object-cover w-24 h-20 lg:w-28 lg:h-24 shadow-sm rounded-xl mr-4 lg:mr-10" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                            <div class="flex flex-col w-full mr-8">
                                <h1 class=" text-xs md:text-lg lg:text-md text-left font-medium md:text-normal lg:text-left" style="color:#504A50; font-family:'Asap';">
                                    The title of the name of the art and other paintings.
                                </h1>
                                <p class="mt-2 text-left text-lg md:text-2xl lg:text-3xl" style="color:#8B8282; font-family: 'Asap';">
                                    $350
                                </p>
                            </div>
                            <div class="flex flex-col ">
                                <a href="#" type="button" class="text-white rounded-lg border border-bg-red-500 bg-red-500">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                        <div class="flex flex-row mb-10 mr-6">
                            <div class="flex flex-col w-full mr-2 justify-center items-center">
                                <select class="w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                    <option>Physical Print</option>
                                    <option>Type 1</option>
                                </select>
                                <div class="flex flex-row w-full mt-4">
                                    <select class="mr-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>100x200cm</option>
                                        <option>Type 1</option>
                                    </select>
                                    <select class="ml-2 w-full h-10 px-3 text-artiliser rounded border-white text-sm font-extrabold focus:ring-artiliser" style="background-color:#F5ECF5; font-family:'Nunito', sans-serif;">
                                        <option>Canvas</option>
                                        <option>Type 1</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="border mr-8 mb-10" style="color:#F0EAEA;"></div>
                        <h1 class="mt-10text-xl text-left font-extrabold md:text-4xl mb-10" style="color:#670067; font-family:'Asap';">Shipping Details</h1>
                        <div class="border rounded-lg grid mr-8 mb-10" style="background-color:#FBF0F0; border-color:#EF9BEF">
                            <div class="flex flex-row w-full">
                                <!-- Icon -->
                                <div class="px-4 py-4 text-artiliser">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                    </svg>
                                </div>
                                <!-- Nama dan Alamat -->
                                <div class="flex flex-col py-4 w-full">
                                    <h1 class=" text-sm md:text-md text-left font-semibold md:text-left" style="color:#656363;  font-family:'Asap';">
                                        Daniel Radcliffe
                                    </h1>
                                    <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Ingram Road, North Wilkesboro, NC 28659,North
                                    </p>
                                    <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Wilkesboro,United States, 4211 |
                                    </p>
                                    <p class="text-sm md:text-md text-left  md:text-left" style="color:#656363;  font-family: 'Nunito';">
                                        Daniel@youremail.com
                                    </p>
                                </div>
                                <!-- Button Edit -->
                                <div class="px-4 py-4 text-artiliser">
                                    <a href="#" type="button" class="font-bold text-artiliser hover:text-artiliserdark focus:text-artiliserdark">Edit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Bagian Kanan -->
                    <div class="flex flex-col w-full">
                        <div class="border rounded-lg grid mr-8 mb-6" style="background-color:#FCFCFC; border-color:#E9CFE9">
                            <div class="flex flex-col w-full">
                                <!-- Title -->
                                <div class="px-4 py-4 text-artiliser">
                                    <h1 class=" text-sm md:text-md text-left font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                        Cost Information
                                    </h1>
                                </div>
                                <!-- Content -->
                                <div class="flex flex-row px-4 mb-4">
                                    <h1 class=" text-xs md:text-sm text-left md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                        The title of the name of the art and other paintings. 2
                                    </h1>
                                    <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                        $350
                                    </p>
                                </div>
                                <div class="flex flex-row px-4 mb-4">
                                    <h1 class=" text-xs md:text-sm text-left md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                        The title of the name of the art and other paintings.
                                    </h1>
                                    <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                        $500
                                    </p>
                                </div>
                                <div class="border-b mx-4 mb-4" style="border-color:#F0EAEA"></div>
                                <!-- Title -->
                                <div class="px-4 text-artiliser">
                                    <h1 class=" text-sm md:text-md text-left font-bold md:text-left" style="color:#670067;  font-family:'Montserrat';">
                                        Cost Information
                                    </h1>
                                </div>
                                <!-- Content -->
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-cleftenter font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Courier
                                        </h1>
                                        <p class="text-xs text-left md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                            JNT Express
                                        </p>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $350
                                        </p>
                                    </div>
                                </div>
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-left font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Tax
                                        </h1>
                                        <p class="text-xs text-left md:text-left" style="color:#7C7171;  font-family: 'Montserrat';">
                                            Country 20%
                                        </p>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-xs md:text-sm  text-center  md:text-left" style="color:#46814C;  font-family: 'Montserrat';">
                                            $200
                                        </p>
                                    </div>
                                </div>
                                <div class="flex flex-row px-4 mb-4 ">
                                    <div class="flex flex-col w-full">
                                        <h1 class=" text-xs md:text-sm text-left font-bold md:text-left w-full mr-2" style="color:#504A50;  font-family:'Montserrat';">
                                            Total price
                                        </h1>
                                    </div>
                                    <div class="flex justify-center items-center">
                                        <p class="text-md md:text-xl font-bold text-center  md:text-left" style="color:#5F82C5;  font-family: 'Montserrat';">
                                            $1,200
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="flex flex-row mr-8 mb-20 text-center">
                            <div class="border-2 text-sm rounded-lg w-1/2 mr-2 py-1 border-artiliser text-artiliser hover:text-white hover:bg-artiliser">
                                <a href="#" type="button" class="">Cancel</a>
                            </div>
                            <div class="border-2 text-sm rounded-lg w-1/2 ml-2 py-1 bg-artiliser border-artiliser text-white hover:text-white hover:bg-artiliserdark">
                                <a href="#" type="button" class="">Checkout</a>
                            </div>
                        </div>   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-artiliser w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                <!-- Footer -->
                <div class="bottom-0 text-center">
                    <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userfrontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/frontend/gallery/cart.blade.php ENDPATH**/ ?>