<?php return array (
  'show-posts' => 'App\\Http\\Livewire\\ShowPosts',
);