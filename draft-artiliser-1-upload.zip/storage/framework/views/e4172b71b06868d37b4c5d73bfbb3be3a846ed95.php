
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <link rel="shortcut icon" href="./assets/img/favicon.ico" />
    <link
      rel="apple-touch-icon"
      sizes="76x76"
      href="./assets/img/apple-icon.png"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/gh/creativetimofficial/tailwind-starter-kit/compiled-tailwind.min.css"
    />
    <title>Profile</title>
  </head>
    <main class="profile-page">
      <section class="relative block" style="height: 300px;">
        <div
          class="absolute top-0 w-full h-full bg-center bg-cover"
          style='background-color:#fce8ff;'>
        </div>
        <div
          class="top-auto bottom-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden"
          style="height: 70px;"
        >
          <svg
            class="absolute bottom-0 overflow-hidden"
            xmlns="http://www.w3.org/2000/svg"
            preserveAspectRatio="none"
            version="1.1"
            viewBox="0 0 2560 100"
            x="0"
            y="0"
          >
            <polygon
              class="text-gray-300 fill-current"
              points="2560 0 2560 100 0 100"
            ></polygon>
          </svg>
        </div>
      </section>
      <section class="relative py-16 bg-gray-300">
        <div class="container mx-auto px-4">
          <div
            class="relative flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-xl rounded-lg -mt-64"
          >
            <div class="px-6">
              <div class="flex flex-wrap justify-center">
                <div
                  class="w-full lg:w-3/12 px-4 lg:order-2 flex justify-center"
                >
                  <div class="relative">
                    <img
                      alt="..."
                      src="https://source.unsplash.com/MP0IUfwrn0A"
                      class="shadow-xl rounded-full h-auto align-middle border-none absolute -m-16 -ml-10 lg:-ml-16"
                      style="max-width: 150px;"
                    />
                  </div>
                </div>
                </div>
                <div
                  class="w-full lg:w-4/12 px-4 lg:order-3 lg:text-right lg:self-center"
                >
                  <div class="py-6 px-3 mt-32 sm:mt-0">
                  </div>
                </div>
                <div class="w-full lg:w-4/12 px-4 lg:order-1">
                  <div class="flex justify-center py-4 lg:pt-4 pt-8">
                    <div class="mr-4 p-3 text-center">
                      <span
                        class="text-xl font-bold block uppercase tracking-wide text-gray-700"
                        ></span
                      ><span class="text-sm text-gray-500"></span>
                    </div>
                    <div class="mr-4 p-3 text-center">
                      <span
                        class="text-xl font-bold block uppercase tracking-wide text-gray-700"
                        ></span
                      ><span class="text-sm text-gray-500"></span>
                    </div>
                    <div class="lg:mr-4 p-3 text-center">
                      <span
                        class="text-xl font-bold block uppercase tracking-wide text-gray-700"
                        ></span
                      ><span class="text-sm text-gray-500"></span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="text-center mt-12">
                <h3
                  class="text-4xl font-semibold leading-normal mb-2 text-gray-800 mb-2"
                >
                  Jenna Stones
                </h3>
                <div
                  class="text-sm leading-normal mt-0 mb-2 text-gray-500 font-bold uppercase"
                >
                  <i
                    class="fas fa-map-marker-alt mr-2 text-lg text-gray-500"
                  ></i>
                  Jimbaran, Bali
                </div>
              </div>

              <div class=" text-center py-6 px-3 mt-32 sm:mt-0">
                    <button
                    style="border-color:#670067; color:#670067; " class="inline-flex items-center justify-center rounded px-2 py-0.5 font-xs leading-6 border text-white rounded-md shadow-sm"
                      type="button"
                    >
                      Edit Profile
                    </button>
  
                    <button
                      style="border-color:#670067; color:#670067; " class="inline-flex items-center justify-center rounded px-2 py-0.5 font-xs leading-6 border text-white rounded-md shadow-sm"
                      type="button"
                    >
                      Change Password
                    </button>
                </div>

              <div class="mt-5 py-5 border-t border-gray-300 text-center">
              <h5
                  class="text-xl font-semibold leading-normal mb-1 text-gray-800 mb-1"
                >
                Order History
                </h5>
                <div class="flex flex-wrap justify-center">
                <table class="table-fixed">
                <thead>
                    <tr>
                        <th class="w-1/2 ...">Order</th>
                        <th class="w-1/2 ...">Date</th>
                        <th class="w-2/4 ...">Payment Status</th>
                        <th class="w-2/4 ...">Fulfillment Status</th>
                        <th class="w-1/2 ...">Total</th>
                        </tr>
                </thead>
                <tbody>
                        <tr>
                        <td class="border px-4 py-2">#10001</td>
                        <td class="border px-4 py-2">12/06/2021</td>
                        <td class="border px-4 py-2">Paid</td>
                        <td class="border px-4 py-2">Fulfilled</td>
                        <td class="border px-4 py-2">Rp250.000,00</td>
                        </tr>
                        <tr>
                        <td class="border px-4 py-2">#10002</td>
                        <td class="border px-4 py-2">13/06/2021</td>
                        <td class="border px-4 py-2">Voided</td>
                        <td class="border px-4 py-2">Unfulfilled</td>
                        <td class="border px-4 py-2">Rp170.000,00</td>
                        </tr>
                        <tr>
                        <td class="border px-4 py-2">#10003</td>
                        <td class="border px-4 py-2">14/06/2021</td>
                        <td class="border px-4 py-2">Voided</td>
                        <td class="border px-4 py-2">Unfulfilled</td>
                        <td class="border px-4 py-2">Rp350.000,00</td>
                        </tr>
                </tbody>
                </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
    <footer class="relative bg-gray-300 pt-8 pb-6">
      <div
        class="bottom-auto top-0 left-0 right-0 w-full absolute pointer-events-none overflow-hidden -mt-20"
        style="height: 80px;"
      >
        <svg
          class="absolute bottom-0 overflow-hidden"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          version="1.1"
          viewBox="0 0 2560 100"
          x="0"
          y="0"
        >
          <polygon
            class="text-gray-300 fill-current"
            points="2560 0 2560 100 0 100"
          ></polygon>
        </svg>
      </div>
    </footer>
  </body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userbackend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser\draft-artiliser-1\resources\views/backend/profile/index.blade.php ENDPATH**/ ?>