
<?php $__env->startSection('content'); ?>
<div class="px-2 py-3">
    <div class="flex justify-end items-center">
        <h3 class="font-semibold"></h3>
        <a href="/user/add" type="button" style="background-color:#670067" class="inline-block px-4 py-1 text-xs font-medium leading-6 text-center text-white transition rounded shadow ripple hover:shadow-lg focus:outline-none"><i class="fa fa-plus"></i> Add User</a>
    </div>
</div>
<!-- Card Data Table -->
<div id='recipients' class="p-4 mt-2 lg:mt-0 rounded shadow bg-white">
    <?php if(session ('success')): ?>
        <div class="py-3 px-5 mb-4 bg-green-100 text-green-900 text-sm rounded-md border border-green-200 alert alert-success alert-dismissible">
            <!-- <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> -->
            <h5><i class="icon fas fa-check"></i> <?php echo e(session ('success')); ?> </h5>
        </div>
    <?php endif; ?>
    <table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
        <thead>
            <tr>
                <th data-priority="1">No</th>
                <th data-priority="2">Name</th>
                <th data-priority="3">Email</th>
                <th data-priority="4">Role</th>
                <th data-priority="6">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($no++); ?></td>
                <td class="text-center"><?php echo e($data->name); ?></td>
                <td class="text-center"><?php echo e($data->email); ?></td>
                <td class="text-center"><?php echo e($data->role); ?></td>
                <td class="text-center">
                    <div class="flex item-center justify-center">
                        
                        <div class="w-4 mr-2 transform hover:text-purple-900 hover:scale-110">
                            <a href="<?php echo e(route('user.edit', $data->id)); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                                </svg>
                            </a>
                        </div>
                        <div class="w-4 mr-2 transform hover:text-purple-900 hover:scale-110">
                            <a href="<?php echo e(route('user.delete', $data->id)); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminbackend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/backend/user/index.blade.php ENDPATH**/ ?>