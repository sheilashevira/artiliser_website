<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GalleryController extends Controller
{
    public function index(){
        return view('frontend.gallery.index');
    }
    public function detail(){
        return view('frontend.gallery.detail');
    }
    public function order(){
        return view('frontend.gallery.order-detail');
    }
    public function success(){
        return view('frontend.gallery.success');
    }
    public function error(){
        return view('frontend.gallery.error');
    }
}
