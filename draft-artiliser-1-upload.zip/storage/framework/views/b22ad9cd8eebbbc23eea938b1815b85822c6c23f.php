<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.0-canary.14/tailwind.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet"/>

    <link href='https://fonts.googleapis.com/css?family=Asap' rel='stylesheet'>
</head>
<body>
    <div class="relative min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 bg-gray-500 bg-no-repeat bg-cover relative items-center"
	style="background-color: #fce8ff">
	<div class="max-w-lg w-full space-y-8 p-10 bg-white rounded-xl z-10">
        <div class="flex flex-col justify-center items-center relative">
            <!-- <div class="relative"> -->
            <img alt="..." src="https://cdn.discordapp.com/attachments/664629434573258763/854211798740107294/logo_landscape.png" class="w-24 sm:w-36 h-4 sm:h-6 align-middle absolute mb-64 sm:mb-60">
            <h2 class="mt-12 text-xl sm:text-3xl font-bold text-gray-900">
				Check Your Email
			</h2>
			<p class="mt-2 text-sm text-center text-gray-600">We have send a password recover instructions to <b>shevirasheila7@gmail.com</b></p>
            <p class="mt-2 text-sm text-center text-gray-600">You need to verify your email to continue. If you have not received the verification email, please check your "Spam" or "Bulk Email" folder. You can also click the resend button below to have another email sent to you.</p>
        </div>
		<form class="mt-8 space-y-6" action="#" method="POST">
			<div>
				<a href="#" type="submit" class="w-full flex justify-center bg-artiliser text-white p-2.5 rounded-lg">
                    Resend Link
                </a>
			</div>
		</form>
	</div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/backend/profile/check-email.blade.php ENDPATH**/ ?>