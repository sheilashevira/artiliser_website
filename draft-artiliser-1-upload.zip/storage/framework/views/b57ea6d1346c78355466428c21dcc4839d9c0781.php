<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.0-canary.14/tailwind.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet"/>

    <link href='https://fonts.googleapis.com/css?family=Asap' rel='stylesheet'>

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
    <script type="module" src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine-ie11.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.js" defer></script>
    <style>
    @import  url(https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css);
    /**
    * tailwind.config.js
    * module.exports = {
    *   variants: {
    *     extend: {
    *       backgroundColor: ['active'],
    *     }
    *   },
    * }
    */
    .active\:bg-gray-50:active {
        --tw-bg-opacity:1;
        background-color: rgba(249,250,251,var(--tw-bg-opacity));
    }
    </style>

<script>
function app() {
    return {
        wysiwyg: null,
        init: function(el) {
            // Get el
            this.wysiwyg = el;
            // Add CSS
            this.wysiwyg.contentDocument.querySelector('head').innerHTML += `<style>
            *, ::after, ::before {box-sizing: border-box;}
            :root {tab-size: 4;}
            html {line-height: 1.15;text-size-adjust: 100%;}
            body {margin: 0px; padding: 1rem 0.5rem;}
            body {font-family: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";}
            </style>`;
            this.wysiwyg.contentDocument.body.innerHTML += `
            `;
            // Make editable
            this.wysiwyg.contentDocument.designMode = "on";
        },
        format: function(cmd, param) {
            this.wysiwyg.contentDocument.execCommand(cmd, !1, param||null)
        }
    }
}
</script>
</head>
<body>
<div class="container mx-auto-px-2"></div>
    <!-- Navbar -->
        <nav class="py-6 flex justify-between px-32 flex justify-between">
            <div class="flex flex-row justify-center">
                <svg height="40" width="40" viewBox="0 0 40 40">
                    <circle cx="15" cy="25" r="10" stroke="black" stroke-width="3" fill="yellow" />
                </svg>
                <h1 class="px-2 text-xl text-center my-auto font-bold" style="color:#670067; font-family: 'Asap';">Artiliser</h1>
            </div>
            <div class="flex flex-row justify-center space-x-4">
                <div class="flex flef-row justify-center space-x-4 text-gray-400 text-sm py-4">
                    <a href="#" class="px-2">Home</a>
                    <a href="#" class="px-2">Gallery</a>
                    <a href="#" class="px-2">About</a>
                    <a href="#" class="px-2">Contact</a>
                    <a href="/profile" class="px-2">Profile</a>
                </div>
                <div class="flex flex-row justify-center items-center my-auto space-x-4 text-sm">
                    <span class="inline-flex rounded-md shadow-sm">
                        <a href="<?php echo e(route('logout')); ?>" style="border-color:#670067; color:#670067; " class="inline-flex items-center justify-center px-2 py-0.5 font-xs leading-6 border text-white rounded-md shadow-sm" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                         </form> 
                    </span>
                    <!-- <a href="#" class="px-2 button rounded text-white" border-radius: 8px; style="background-color:#670067;">Register</a> -->
                    <div class="w-0.5 h-6 bg-gray-400 opacity-30"></div>
                    <svg height="24" viewBox="0 -31 512.00033 500" width="24" xmlns="http://www.w3.org/2000/svg" fill="#670067">
                        <path d="M128,341.333c-23.573,0-42.453,19.093-42.453,42.667s18.88,42.667,42.453,42.667c23.573,0,42.667-19.093,42.667-42.667
                    S151.573,341.333,128,341.333z"/>
               <path d="M151.467,234.667H310.4c16,0,29.973-8.853,37.333-21.973L424,74.24c1.707-2.987,2.667-6.507,2.667-10.24
                                c0-11.84-9.6-21.333-21.333-21.333H89.92L69.653,0H0v42.667h42.667L119.36,204.48l-28.8,52.267
                                c-3.307,6.187-5.227,13.12-5.227,20.587C85.333,300.907,104.427,320,128,320h256v-42.667H137.067
                                c-2.987,0-5.333-2.347-5.333-5.333c0-0.96,0.213-1.813,0.64-2.56L151.467,234.667z"/>
                        <path d="M341.333,341.333c-23.573,0-42.453,19.093-42.453,42.667s18.88,42.667,42.453,42.667
                                C364.907,426.667,384,407.573,384,384S364.907,341.333,341.333,341.333z"/>
                    </svg>    
                </div>        
            </div>
        </nav>
    <!-- Navbar End -->

    <div class="body">
                <div style="background-color: #fce8ff;">
                    <!-- Main content -->
                    <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                        
                        <?php echo $__env->yieldContent('content'); ?>
                        
                        </div>
                    </div>
                    </div>
                    <!-- /.content -->
                </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\draft-artiliser\frontend-sheila\draft-artiliser-1\resources\views/layouts/userbackend.blade.php ENDPATH**/ ?>