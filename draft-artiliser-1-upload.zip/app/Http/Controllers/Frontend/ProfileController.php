<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index(){
        return view('frontend.profile.index');
    }

    public function changePass(){
        return view('frontend.profile.change-password');
    }

    public function editProfile(){
        return view('frontend.profile.edit-profile');
    }
}
