@extends('layouts.userfrontend')
@section('content')
<div class="w-full">
    <div class=" max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto ">
        <div class="grid mx-10 mb-20 lg:mt-10">
            <!-- Carousel 1 Start -->
            <div class="carousel mt-8 lg:mt-0" data-flickity='{ "freeScroll": true, "autoPlay": true, "imagesLoaded":true, "prevNextButtons": false }'>
                <!-- Slide 1 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class="w-full md:pr-0">
                            <img class="float-left object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg" >
                        </div>
                        <div class="pl-0 mt-3 md:pl-10 md:mt-0">
                            <h1 class="float-center text-xl text-center md:text-4xl md:text-left" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum Blabla bla bla bla bla blabalala bla bla bla
                            </h1>
                            <p class="hidden float-right mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                    </div>
                </div>
                <!-- Slide 2 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class="w-full md:pr-0 ">
                            <img class="float-left object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg">
                        </div>
                        <div class="pl-0 mt- md:pl-10 md:mt-0">
                            <h1 class="float-center text-xl text-center md:text-4xl md:text-left" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum Blabla
                            </h1>
                            <p class="hidden float-right mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                    </div>
                </div>
                <!-- Slide 3 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class="w-full md:pr-0 ">
                            <img class="float-left object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg">
                        </div>
                        <div class="pl-0 mt-3 md:pl-10 md:mt-0">
                            <h1 class="float-center text-xl text-center md:text-4xl md:text-left" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem
                            </h1>
                            <p class="hidden float-right mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<div class="w-full">
    <div class=" max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
        <div class="grid mx-10 mb-20 mt-10">
            <!-- Carousel 2 Start -->
            <div class="carousel" data-flickity='{ "freeScroll": true, "autoPlay": true, "imagesLoaded":true, "prevNextButtons": false }'>
                <!-- Slide 1 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:block hidden" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum is simply dummy text of the printing.
                            </h1>
                            <p class="hidden mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                        <div class="">
                            <img class="float-right object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg">
                        </div>
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:hidden block" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum is simply dummy text of the printing.
                            </h1>
                        </div>
                    </div>
                </div>
                <!-- Slide 2 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:block hidden" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum is simply dummy text
                            </h1>
                            <p class="hidden mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                        <div class="">
                            <img class="float-right object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg">
                        </div>
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:hidden block" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum is simply dummy text
                            </h1>
                        </div>
                    </div>
                </div>
                <!-- Slide 3 -->
                <div class="carousel-cell">
                    <div class="grid items-center grid-cols-1 md:grid-cols-2">
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:block hidden" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum
                            </h1>
                            <p class="hidden mt-8 text-left text-gray-700 lg:block xl:block" style="font-family: 'Montserrat', sans-serif;">
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in
                            </p>
                        </div>
                        <div class="">
                            <img class="float-right object-cover w-full shadow-sm lg:w-5/6 h-60 md:h-80 xl:h-96 rounded-3xl" src="https://cdn.devdojo.com/images/november2020/hero-image.jpeg">
                        </div>
                        <div class=" md:pr-10">
                            <h1 class="text-xl text-center md:text-4xl md:text-left md:hidden block" style="color:#670067; font-family:Asap; font-weight:1000">
                                Lorem Ipsum
                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<div class="bg-artiliserthin w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
        <div class="grid mx-10 mt-10 mb-10">
            <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Gallery</h1>
            <!-- Photo Grid Card 1-->
            <div class="lg:flex items-center  container mx-auto my-auto">
                <!-- Card 1 -->
                <div class="lg:flex-col items-center container mx-auto my-auto mr-4 hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                    <!-- Image -->
                    <div class="flex items-center justify-center">
                        <img src="https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:w-4/5 md:h-96 w-full h-52 overflow-hidden rounded-3xl">
                    </div>
                    <!-- Content -->
                    <div class="flex md:items-left items-center md:justify-start justify-center">
                        <div class="p-4">
                            <p class=" text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;">
                            Art deisgn theme, forest..
                            </p>
                            <p class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab. 
                            </p>
                            <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0">
                                <a href="" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser " style="font-family: 'Montserrat', sans-serif;">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Card 2 -->
                <div class="lg:flex-col items-center container mx-auto my-auto mr-4 hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                    <!-- Image -->
                    <div class="flex items-center justify-center">
                        <img src="https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:w-4/5 md:h-96 w-full h-52 overflow-hidden rounded-3xl">
                    </div>
                    <!-- Content -->
                    <div class="flex md:items-left items-center md:justify-start justify-center">
                        <div class="p-4">
                            <p class="text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;">
                            Art deisgn theme, forest..
                            </p>
                            <p class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab. 
                            </p>
                            <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0">
                                <a href="" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser" style="font-family: 'Montserrat', sans-serif;">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Card 3 -->
                <div class="lg:flex-col items-center container mx-auto my-auto hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                    <!-- Image -->
                    <div class="flex items-center justify-center">
                        <img src="https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:w-4/5 md:h-96 w-full h-52 overflow-hidden rounded-3xl">
                    </div>
                    <!-- Content -->
                    <div class="flex md:items-left items-center md:justify-start justify-center">
                        <div class="p-4">
                            <p class="text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;">
                            Art deisgn theme, forest..
                            </p>
                            <p class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab. 
                            </p>
                            <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0">
                                <a href="" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser" style="font-family: 'Montserrat', sans-serif;">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Photo Grid Card 1-->
            <div class="container md:mx-auto " x-data="loadGallery()">
                <div class="box-wrapper flex flex-row flex justify-center items-center ml-4 hidden">
                    <div class=" bg-white rounded-lg flex items-center w-32 md:w-80 lg:w-96 p-3 shadow-lg border border-gray-200" style="font-family: 'Montserrat', sans-serif;">
                    <button @click="getImages()" class="outline-none focus:outline-none">
                        <svg class=" w-4 md:w-5 text-gray-600 h-4 md:h-5 cursor-pointer" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24">
                            <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                        </svg>
                    </button>
                    <input x-ref="searchField" x-model="search" x-on:click="viewPage(0)" x-on:keydown.window.prevent.slash=" viewPage(0), $refs.searchField.focus()" placeholder="Search..." type="search" class="w-full pl-4 text-sm outline-none focus:outline-none bg-transparent">
                    </div>
                    <div class=" bg-white rounded-lg flex items-center w-28 md:w-28 lg:w-32 p-3 shadow-lg border border-gray-200 mx-4" style="font-family: 'Montserrat', sans-serif;">
                    <div class="select">
                        <select name="" id="" class="text-xs md:text-sm outline-none focus:outline-none bg-transparent">
                            <option value="filterby" selected>Filter By</option>
                            <option value="category 1">Category 1</option>
                            <option value="category 2">Category 2</option>
                            <option value="category 3">Category 3</option>
                            </select>
                    </div>  
                    </div>
                </div>
                <div class=" grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 grid-rows-1 gap-4 ">
                    <template x-for="item in filteredGallery" :key="item" class="items-center container mx-auto my-auto">
                    <div class="lg:flex-col items-center container mx-auto my-auto hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                        <div class="flex items-center justify-center">
                        <img :src="`${item.image}`" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:full md:h-72 w-full h-52 overflow-hidden rounded-3xl">
                        </div>
                        <div class="flex md:items-left items-center md:justify-start justify-center">
                        <div class="p-4">
                            <p x-text="item.title" class=" text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;"></p>
                            <p x-text="item.content" class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;"></p>
                            <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0">
                            <a href="/gallery/detail" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser " style="font-family: 'Montserrat', sans-serif;">Read More</a>
                            </div>
                        </div>
                        </div>
                    </div>
                    </template>
                </div>
            </div>
            <a href="#" class=" text-center mt-6 lg:mt-10 font-semibold hover:text-purple-900 text-sm text-artiliser" style="font-family: 'Montserrat', sans-serif;">Click See More..</a>
        </div>
        </div>
    </div>
</div>
<div class="w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-10 mb-20">
            <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Contact Us</h1>
                <!-- Contact Us-->
                <div class="">
                    <form class="md:mx-32 lg:mx-60 xl:mx-96 space-y-6 px-8 " action="#" method="POST">
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Name" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Email" type="email" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Message" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-40 focus:placeholder-table focus:border-artiliser px-3 pb-28 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="relative flex justify-center items-center">
                        <a href="#" type="submit" class="w-32 h-10 hover-artiliserdark hover:bg-artiliserdark hover:text-white flex justify-center bg-artiliser text-white p-2 rounded-lg hover:text-white" style="font-family: 'Montserrat', sans-serif;">
                        Send
                        </a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-artiliser w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                <!-- Footer -->
                <div class="bottom-0 text-center">
                    <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
      var sourceData = [
        {
          id: "1",
          title: "Sheila Shevira..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "2",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "3",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "4",
          title: "Sheila Shevira..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "5",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "6",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "7",
          title: "Sheila Shevira..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "8",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "9",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
      ];
      function loadGallery() {
        return {
          search: "",
          pageNumber: 0,
          size: 9,
          total: "",
          myForData: sourceData,

          get filteredGallery() {
            const start = this.pageNumber * this.size,
              end = start + this.size;

            if (this.search === "") {
              this.total = this.myForData.length;
              return this.myForData.slice(start, end);
            }

            //Return the total results of the filters
            this.total = this.myForData.filter((item) => {
              return item.title
                .toLowerCase()
                .includes(this.search.toLowerCase());
            }).length;

            //Return the filtered data
            return this.myForData
              .filter((item) => {
                return item.title
                  .toLowerCase()
                  .includes(this.search.toLowerCase());
              })
              .slice(start, end);
          },
        };
      }
</script>    
@endsection