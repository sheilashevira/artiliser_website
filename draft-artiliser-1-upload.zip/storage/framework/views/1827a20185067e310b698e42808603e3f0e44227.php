<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.0-canary.14/tailwind.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet"/>

    <link href='https://fonts.googleapis.com/css?family=Asap' rel='stylesheet'>

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
    <script type="module" src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine-ie11.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.js" defer></script>
    <style>
    @import  url(https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css);
    /**
    * tailwind.config.js
    * module.exports = {
    *   variants: {
    *     extend: {
    *       backgroundColor: ['active'],
    *     }
    *   },
    * }
    */
    .active\:bg-gray-50:active {
        --tw-bg-opacity:1;
        background-color: rgba(249,250,251,var(--tw-bg-opacity));
    }
    </style>

<script>
function app() {
    return {
        wysiwyg: null,
        init: function(el) {
            // Get el
            this.wysiwyg = el;
            // Add CSS
            this.wysiwyg.contentDocument.querySelector('head').innerHTML += `<style>
            *, ::after, ::before {box-sizing: border-box;}
            :root {tab-size: 4;}
            html {line-height: 1.15;text-size-adjust: 100%;}
            body {margin: 0px; padding: 1rem 0.5rem;}
            body {font-family: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";}
            </style>`;
            this.wysiwyg.contentDocument.body.innerHTML += `
            `;
            // Make editable
            this.wysiwyg.contentDocument.designMode = "on";
        },
        format: function(cmd, param) {
            this.wysiwyg.contentDocument.execCommand(cmd, !1, param||null)
        }
    }
}
</script>
</head>
<body style="background-color:#fce8ff;">
    <div class="flex" style="font-family: Arial;" x-data="{ open: true }">
        <div class="sidebar h-screen" style="width: 260px;" x-show="open">
            <div class="bg-white">
                <div class="h-14 mx-auto block px-4 py-5" style="background-color:#670067; color:#ffffff">
                    WELCOME, ADMIN
                </div>
                <div class="overflow-y-auto overflow-x-hidden flex-grow">
            <ul class="flex flex-col py-4 space-y-1">
                <li class="px-5">
                <div class="flex flex-row items-center h-8">
                    <div class="text-sm font-light tracking-wide text-gray-500">Dashboard</div>
                </div>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M16 20h4v-4h-4m0-2h4v-4h-4m-6-2h4V4h-4m6
                            4h4V4h-4m-6 10h4v-4h-4m-6 4h4v-4H4m0 10h4v-4H4m6
                            4h4v-4h-4M4 8h4V4H4v4z"
                    ></path>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Dashboard</span>
                </a>
                </li>
                <li class="px-5">
                <div class="flex flex-row items-center h-8">
                    <div class="text-sm font-light tracking-wide text-gray-500">Menu</div>
                </div>
                </li>
                <li>
                <a href="/post" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg enable-background="new 0 0 24 24" height="19" viewBox="0 0 24 24" width="19" xmlns="http://www.w3.org/2000/svg">
                        <path d="m17.5 24c-3.584 0-6.5-2.916-6.5-6.5s2.916-6.5 6.5-6.5 6.5 2.916 6.5 6.5-2.916 6.5-6.5 6.5zm0-11.5c-2.757 0-5 2.243-5 5s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5z"/>
                        <path d="m17.5 21c-.414 0-.75-.336-.75-.75v-5.5c0-.414.336-.75.75-.75s.75.336.75.75v5.5c0 .414-.336.75-.75.75z"/><path d="m20.25 18.25h-5.5c-.414 0-.75-.336-.75-.75s.336-.75.75-.75h5.5c.414 0 .75.336.75.75s-.336.75-.75.75z"/>
                        <path d="m9.19 21h-6.44c-1.517 0-2.75-1.233-2.75-2.75v-15.5c0-1.517 1.233-2.75 2.75-2.75h11.5c1.517 0 2.75 1.233 2.75 2.75v6.09c0 .414-.336.75-.75.75s-.75-.336-.75-.75v-6.09c0-.689-.561-1.25-1.25-1.25h-11.5c-.689 0-1.25.561-1.25 1.25v15.5c0 .689.561 1.25 1.25 1.25h6.44c.414 0 .75.336.75.75s-.336.75-.75.75z"/>
                        <path d="m13.25 9.5h-9.5c-.414 0-.75-.336-.75-.75s.336-.75.75-.75h9.5c.414 0 .75.336.75.75s-.336.75-.75.75z"/><path d="m9.25 13.5h-5.5c-.414 0-.75-.336-.75-.75s.336-.75.75-.75h5.5c.414 0 .75.336.75.75s-.336.75-.75.75z"/>
                        <path d="m8.25 5.5h-4.5c-.414 0-.75-.336-.75-.75s.336-.75.75-.75h4.5c.414 0 .75.336.75.75s-.336.75-.75.75z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Posts</span>
                </a>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg enable-background="new 0 0 512 512" height="19" viewBox="0 0 512 512" width="19" xmlns="http://www.w3.org/2000/svg">>
                        <path d="m507.786 64.62c-.304-.286-60.445-57.641-60.445-57.641-2.299-2.206-4.677-4.486-9.117-4.486h-242.12c-7.072 0-12.826 5.753-12.826 12.825v39.383l-85.335 14.628c-6.84 1.2-11.44 7.746-10.255 14.579l4.331 25.252c-27.737 9.334-56.214 18.956-83.705 28.831-6.496 2.375-9.905 9.598-7.587 16.133l54.685 152.016c1.1 3.059 3.983 4.964 7.058 4.964.842 0 1.7-.143 2.538-.445 3.898-1.402 5.921-5.698 4.519-9.596l-53.876-149.768c25.9-9.273 52.722-18.349 78.935-27.172l25.771 150.245 29.654 173.032c1.071 6.108 6.44 10.454 12.5 10.454.686 0 1.382-.056 2.08-.171l80.316-13.783 62.76-10.758-94.391 33.927-74.435 26.763-57.808-160.789c-1.401-3.898-5.696-5.921-9.595-4.52-3.898 1.401-5.921 5.697-4.52 9.595l58.628 163.074c1.875 5.128 6.733 8.316 11.868 8.316 1.419 0 2.86-.244 4.264-.757l76.671-27.566 174.094-62.574 33.259-5.701h73.471c7.072 0 12.826-5.766 12.826-12.854v-326.985c.001-4.489-2.435-6.779-4.213-8.451zm-19.871 1.776h-37.53l-.93.004c-1.797.012-6.004.043-7.071-1.017-.246-.245-.534-1.063-.534-2.582l-.087-40.415zm9.085 331.512h-298.722v-146.167c0-4.142-3.358-7.5-7.5-7.5s-7.5 3.358-7.5 7.5v148.313c0 7.087 5.754 12.854 12.826 12.854h140.812l-94.545 16.206-77.982 13.383-29.248-170.665-32.269-188.13 80.405-13.783v147.022c0 4.142 3.358 7.5 7.5 7.5s7.5-3.358 7.5-7.5v-199.449h228.475l.098 45.326c0 5.494 1.671 9.938 4.966 13.21 5.063 5.027 12.22 5.377 16.663 5.377.382 0 .744-.003 1.083-.005l47.438-.003z"/>
                        <path d="m234.43 118.949c0 4.142 3.358 7.5 7.5 7.5h214.436c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5h-214.436c-4.142 0-7.5 3.358-7.5 7.5z"/>
                        <path d="m456.366 164.731h-214.436c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h214.436c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5z"/><path d="m456.366 218.013h-214.436c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h214.436c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5z"/>
                        <path d="m456.366 271.295h-214.436c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h214.436c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5z"/>
                        <path d="m456.366 324.578h-214.436c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h214.436c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Print Materials</span>
                </a>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg enable-background="new 0 0 512 512" height="19" viewBox="0 0 512 512" width="19" xmlns="http://www.w3.org/2000/svg">
                        <path d="m324.46 490.265h-174.81c-24.041 0-43.6-19.559-43.6-43.6 0-24.035 19.559-43.59 43.6-43.59h55.25c4.142 0 7.5-3.358 7.5-7.5v-279.14c0-4.142-3.358-7.5-7.5-7.5h-95.2c-4.142 0-7.5 3.358-7.5 7.5v51.52c0 24.041-19.559 43.6-43.6 43.6s-43.6-19.559-43.6-43.6v-74.84c0-4.142-3.358-7.5-7.5-7.5s-7.5 3.358-7.5 7.5v74.84c0 32.312 26.288 58.6 58.6 58.6s58.6-26.288 58.6-58.6v-44.02h80.2v264.14h-47.75c-32.312 0-58.6 26.283-58.6 58.59 0 32.312 26.288 58.6 58.6 58.6h174.81c4.142 0 7.5-3.358 7.5-7.5s-3.358-7.5-7.5-7.5z"/><path d="m453.4 6.735h-394.8c-31.487 0-57.202 24.625-58.543 56.06-.177 4.138 3.035 7.636 7.173 7.813 4.145.178 7.636-3.035 7.813-7.173.998-23.383 20.13-41.7 43.557-41.7h394.8c24.041 0 43.6 19.559 43.6 43.6v102.62c0 24.041-19.559 43.6-43.6 43.6-24.036 0-43.59-19.559-43.59-43.6v-51.52c0-4.142-3.358-7.5-7.5-7.5h-95.21c-4.142 0-7.5 3.358-7.5 7.5v161.941c-6.941-.318-13.763 2.273-18.749 7.26-5.796 5.796-8.368 14.069-6.88 22.129l16.832 91.381c2.067 11.237 11.863 19.393 23.292 19.393h17.446c11.789 0 22.874 4.593 31.213 12.931l3.962 3.962c-.689 2.381-1.051 4.873-1.051 7.42 0 7.095 2.763 13.766 7.78 18.782 5.017 5.017 11.688 7.78 18.783 7.78 2.796 0 5.524-.435 8.112-1.262-7.474 13.26-21.67 22.113-37.99 22.113h-7.89c-4.142 0-7.5 3.358-7.5 7.5s3.358 7.5 7.5 7.5h7.89c30.625 0 55.702-23.191 58.362-53.334l36.136-36.136c10.357-10.357 10.357-27.208 0-37.565-5.017-5.017-11.688-7.78-18.783-7.78-2.55 0-5.044.363-7.427 1.053l-3.95-3.95c-8.341-8.351-12.935-19.441-12.935-31.228v-17.447c0-11.426-8.155-21.222-19.392-23.292l-79.761-14.691v-156.96h80.21v44.02c0 32.312 26.283 58.6 58.59 58.6 32.312 0 58.6-26.288 58.6-58.6v-102.62c0-32.312-26.288-58.6-58.6-58.6zm-7.158 382.102c4.508 4.508 4.508 11.844 0 16.352l-45.839 45.839c-2.184 2.184-5.087 3.386-8.176 3.386s-5.992-1.203-8.176-3.386c-2.184-2.184-3.386-5.088-3.386-8.176s1.203-5.992 3.386-8.176l45.839-45.839c2.254-2.254 5.215-3.381 8.176-3.381s5.922 1.127 8.176 3.381zm-47.488-69.958v17.447c0 15.79 6.151 30.644 17.325 41.831l1.639 1.639-42.713 42.713-1.645-1.645c-11.172-11.172-26.024-17.325-41.819-17.325h-17.446c-4.191 0-7.783-2.989-8.541-7.109l-16.833-91.385c-.065-.355-.104-.708-.131-1.061l26.718 26.726c-5.906 10.547-4.388 24.164 4.571 33.122 5.399 5.399 12.491 8.099 19.583 8.099s14.185-2.7 19.583-8.099c10.798-10.798 10.798-28.369 0-39.167-8.961-8.962-22.585-10.478-33.134-4.565l-26.719-26.727c.355.028.712.067 1.069.133l91.382 16.832c4.122.76 7.111 4.351 7.111 8.541zm-68.268 16.392c2.475-2.475 5.726-3.712 8.977-3.712s6.502 1.238 8.977 3.712c4.95 4.95 4.95 13.004 0 17.954s-13.004 4.95-17.954 0c-4.95-4.949-4.95-13.004 0-17.954z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Print Types</span>
                </a>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg enable-background="new 0 0 512 512" height="20" viewBox="0 0 512 512" width="20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M458.159,86.986H169.971c-9.453,0-17.14,7.688-17.14,17.141v75.12H17.141C7.688,179.247,0,186.935,0,196.385v174.783
                            c0,9.458,7.688,17.145,17.141,17.145h288.185c9.458,0,17.14-7.687,17.14-17.145v-75.119h135.694c9.45,0,17.14-7.684,17.14-17.139
                            V104.127C475.291,94.674,467.605,86.986,458.159,86.986z M305.656,371.168c0,0.181-0.145,0.334-0.331,0.334l-288.509-0.334
                            l0.331-175.112l288.509,0.329V371.168z M458.481,278.91c0,0.181-0.146,0.329-0.332,0.329l-135.685-0.153v-82.701
                            c0-9.45-7.694-17.138-17.145-17.138H169.826l0.141-75.451l288.51,0.331V278.91H458.481z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Categories</span>
                </a>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="20px" height="20px" viewBox="0 0 93.849 93.85" style="enable-background:new 0 0 93.849 93.85;"
                        xml:space="preserve">
                    <polygon points="13.36,7.623 62.939,7.623 62.939,10.836 67.347,10.836 67.347,0 62.939,0 62.939,3.215 13.36,3.215 13.36,0 
                                     8.949,0 8.949,10.836 13.36,10.836 		"/>
                    <polygon points="85.157,21.524 85.157,17.115 74.319,17.115 74.319,21.524 77.534,21.524 77.534,89.441 74.319,89.441 
                                    74.319,93.85 85.157,93.85 85.157,89.441 81.943,89.441 81.943,21.524 		"/>
                    <path d="M8.693,93.85h58.912V17.115H8.693V93.85z M13.47,21.893h49.358v67.182H13.47V21.893z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Sizes</span>
                </a>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg enable-background="new 0 0 512 512" height="19" viewBox="0 0 512 512" width="19" xmlns="http://www.w3.org/2000/svg">
                        <path d="m452 70h-40v-10c0-33.085938-26.914062-60-60-60h-192c-33.085938 0-60 26.914062-60 60v10h-40c-33.085938 0-60 26.914062-60 60v251c0 33.085938 26.914062 60 60 60h40v11c0 33.085938 26.914062 60 60 60h192c33.085938 0 60-26.914062 60-60v-11h40c33.085938 0 60-26.914062 60-60v-251c0-33.085938-26.914062-60-60-60zm-392 331c-11.027344 0-20-8.972656-20-20v-251c0-11.027344 8.972656-20 20-20h40v291zm312 51c0 11.027344-8.972656 20-20 20h-192c-11.027344 0-20-8.972656-20-20v-392c0-11.027344 8.972656-20 20-20h192c11.027344 0 20 8.972656 20 20zm100-71c0 11.027344-8.972656 20-20 20h-40v-291h40c11.027344 0 20 8.972656 20 20zm0 0"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">Carousel Rows</span>
                </a>
                </li>
                <li class="px-5">
                <div class="flex flex-row items-center h-8">
                    <div class="text-sm font-light tracking-wide text-gray-500">About</div>
                </div>
                </li>
                <li>
                <a href="#" class="relative flex flex-row items-center h-11 focus:outline-none hover:bg-gray-50 text-gray-600 hover:text-gray-800 border-l-4 border-transparent pr-6">
                    <span class="inline-flex justify-center items-center ml-4">
                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                        width="20px" height="20px" viewBox="0 0 496.304 496.303" style="enable-background:new 0 0 496.304 496.303;"
                        xml:space="preserve">
                    <path d="M248.146,0C111.314,0,0,111.321,0,248.152c0,136.829,111.314,248.151,248.146,248.151
                            c136.835,0,248.158-111.322,248.158-248.151C496.304,111.321,384.98,0,248.146,0z M248.146,472.093
                            c-123.473,0-223.935-100.459-223.935-223.941c0-123.479,100.462-223.941,223.935-223.941
                            c123.488,0,223.947,100.462,223.947,223.941C472.093,371.634,371.634,472.093,248.146,472.093z M319.536,383.42v32.852
                            c0,1.383-1.123,2.494-2.482,2.494H196.45c-1.374,0-2.482-1.117-2.482-2.494V383.42c0-1.372,1.114-2.482,2.482-2.482h34.744V205.831
                            h-35.101c-1.375,0-2.468-1.111-2.468-2.474v-33.6c0-1.38,1.1-2.479,2.468-2.479h82.293c1.371,0,2.482,1.105,2.482,2.479v211.181
                            h36.186C318.413,380.938,319.536,382.048,319.536,383.42z M209.93,105.927c0-20.895,16.929-37.829,37.829-37.829
                            c20.886,0,37.826,16.935,37.826,37.829s-16.94,37.829-37.826,37.829C226.853,143.756,209.93,126.822,209.93,105.927z"/>
                    </svg>
                    </span>
                    <span class="ml-2 text-sm tracking-wide truncate">About</span>
                </a>
                </li>
            </ul>
            </div>
            </div>
        </div>  
        <div class="w-full z-10">
            <div
                class="sticky top-0 header bg-white h-14 px-3 py-4 flex items-center justify-between" style="background-color:#670067">
                <div class="flex items-center space-x-12 text-sm">
                    <i class="hover:text-purple text-xl fas fa-bars font-thin cursor-pointer text-white"
                        @click="open = !open"></i>
                    <span style="color:white; font-size:12pt" class="uppercase font-bold">Dashboard</span></a>
                </div>
                <div class="flex items-center space-x-4 text-gray-400 text-base px-2 py-2">
                    <a class="text-white text-sm" class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                    <i  class="fas fa-sign-out-alt"></i>
                         Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form> 
                </div>
            </div>
            <div class="body">
                <div style="background-color: #fce8ff;">
                    <!-- Main content -->
                    <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                        
                        <?php echo $__env->yieldContent('content'); ?>
                        
                        </div>
                    </div>
                    </div>
                    <!-- /.content -->
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\draft-artiliser\resources\views/layouts/adminbackend.blade.php ENDPATH**/ ?>