
<?php $__env->startSection('content'); ?>
 <div class="shadow-md bg-white rounded px-10 pt-6 pb-8 mb-4 flex flex-col my-5 mx-3" >
  <form action="/user/update/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
   <?php if(isset($data->profiles)): ?>
   <ul class="flex border-b">
    <li class="-mb-px mr-1">
      <a class="bg-white inline-block border-l border-t border-r rounded-t py-2 px-4 text-artiliser font-semibold" href="<?php echo e(route('user.edit', $data->id)); ?>">Details Profile</a>
    </li>
    <li class="mr-1">
      <a class="bg-white inline-block py-2 px-4 text-artiliser hover:text-blue-800 font-semibold" href="<?php echo e(route('user.changePassword', $data->id)); ?>">Change Password</a>
    </li>
   </ul>
   <div class="md:flex sm:mb-2 sm:ml-6 sm:mr-12">
      <div class="md:flex-shrink-0">
        <div class="flex justify-center md:justify-end">
          <?php if(empty($data->profiles->image)): ?>
          <label for="image-input" >
            <img id="preview-image" class="w-36 h-36 object-cover rounded-full border-2 mt-3" src="https://bit.ly/3ubuq5o" alt="">
              <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </label>
          <?php else: ?>
          <label for="image-input" >
            <img id="preview-image" class="w-36 h-36 object-cover rounded-full border-2 mt-3"  alt="" src="/img/<?php echo e($data->profiles->image); ?>" alt="">
              <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </label>
          <?php endif; ?>
        </div>
        <div class="flex items-center justify-center bg-grey-lighter">
          <label class="w-28 flex flex-col items-center px-1 py-2 mt-2 mb-2 bg-artiliser text-blue rounded-lg shadow-lg tracking-wide border border-blue cursor-pointer hover:bg-blue hover:text-white">
              <span class="text-sm text-white">Change Photo</span>
              <input name="image" class="hidden" id="image-input" type='file' onchange="loadFile(this)" accept="image/*">
              
          </label>
      </div>
          
      </div>
      <div class="md:w-full px-3 sm:mb-2 md:ml-14">
        <h2 class="text-gray-800 text-1xl font-semibold text-start sm:mt-6">Name</h2>
        <div class="divide-y divide-artiliser md:divide-y-1">
          <input name="name" class="apperance-none w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->name); ?>">
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">Email</h2>
        <div class="divide-y divide-artiliser md:divde-y-1">
          <input name="email" class="appearance-none w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->email); ?>">
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div> 
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">Role</h2> 
        <div class="divide-y divide-artiliser md:divide-y-1">
          <select name="role" class="w-full text-1xl text-grey-darker mt-1 focus:outline-none">
            <option value=" <?php echo e($data->role); ?>"><?php echo e($data->role); ?></option>
            <option value="Customer">Customer</option>
            <option value="Admin">Admin</option>
          </select>
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['record'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">Address</h2>
        <div class="divide-y divide-artiliser md:divide-y-1">
          <input name="address" class="appearance-none w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->profiles->address); ?>">
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">Zip Code</h2>
        <div class="divide-y divide-artiliser md:divide-y-1">
          <input name="zip_code" class="appearance-none w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->profiles->zip_code); ?>">
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['zip_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">Country</h2>
        <div class="form-group mb-3 divide-y divide-artiliser md:divide-y-1">
          <select  id="country-dd" name="countries_id" class="form-control w-full text-1xl text-grey-darker mt-1 focus:outline-none">
              <option value="<?php echo e($data->profiles->countries['id']); ?>"><?php echo e($data->profiles->countries['name']); ?></option>
              <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <div class="py-2 text-red-500">
            <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <?php echo e($message); ?>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">State</h2>
        <div class="form-group mb-3 divide-y divide-artiliser md:dibide-y-1">
            <select id="state-dd" name="states_id" class="form-control w-full text-1xl text-grey-darker mt-1 focus:outline-none">
              <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($data->states->id); ?>"><?php echo e($data->states->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="py-2 text-red-500">
              <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <h2 class="text-gray-800 text-1xl font-semibold text-start">City</h2>
        <div class="form-group mb-3 divide-y divide-artiliser md:dibide-y-1">
            <select id="city-dd" name="cities_id" class="form-control w-full text-1xl text-grey-darker mt-1 focus:outline-none">
              <?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($data->cities->id); ?>"><?php echo e($data->cities->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="py-2 text-red-500">
              <?php $__errorArgs = ['id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

          
        <div class="flex justify-end mt-4">
        <button type="submit" class="inline-block px-6 bg-artiliser py-1 text-xs font-medium leading-6 text-center text-white transition rounded border shadow ripple hover:shadow-lg focus:outline-none">Save</button>
          <a href="/user" class="inline-block px-6 py-1 text-xs text-artiliser font-medium leading-6 text-center transition bg-transparent border border-artiliser rounded ripple focus:outline-none">Back</a>
        </div>
      </div> 
    </div>
  </div>

  <?php else: ?>
  <ul class="flex border-b">
    <li class="-mb-px mr-1">
      <a class="bg-white inline-block border-l border-t border-r rounded-t py-2 px-4 text-artiliser font-semibold" href="<?php echo e(route('user.edit', $data->id)); ?>">Details Profile</a>
    </li>
    <li class="mr-1">
      <a class="bg-white inline-block py-2 px-4 text-artiliser hover:text-blue-800 font-semibold" href="<?php echo e(route('user.changePassword', $data->id)); ?>">Change Password</a>
    </li>
   </ul>
   <div class="md:flex sm:mb-2">
    <div class="md:flex-shrink-0 "></div>
      <div class="md:w-full px-3 sm:mb-2 md:ml-2">
        <h2 class="text-gray-800 text-1xl font-semibold text-start sm:mt-6">Name</h2>
          <div class="divide-y divide-artiliser md:divide-y-1">
            <input name="name" class="appearance-none  w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->name); ?>">
              <div class="py-2  text-red-500">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>
            <h2 class="text-gray-800 text-1xl font-semibold text-start">Email</h2>
              <div class="divide-y divide-artiliser md:divide-y-1">
                <input name="email"  class="appearance-none  w-full bg-grey-lighter text-1xl text-grey-darker" value="<?php echo e($data->email); ?>">
                  <div class="py-2  text-red-500">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
             <h2 class="text-gray-800 text-1xl font-semibold text-start">Role</h2>
              <div class="divide-y divide-artiliser md:divide-y-1 ">
                <select name="role">
                  <option value="<?php echo e($data->role); ?>"><?php echo e($data->role); ?></option>
                  <option value="Customer">Customer</option>
                  <option value="Admin">Admin</option>
                </select>
                  <div class="py-2  text-red-500">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div> 
              </div>
            </div>
          </div>
          <div class="flex justify-end mt-4">
            <button type="submit" class="inline-block px-6 bg-artiliser py-1 text-xs font-medium leading-6 text-center text-white transition rounded border shadow ripple hover:shadow-lg focus:outline-none">Save</button>
              <a href="/user" class="inline-block px-6 py-1 text-xs text-artiliser font-medium leading-6 text-center transition bg-transparent border border-artiliser rounded ripple focus:outline-none">Back</a>
            </div>
          </div> 
        </div>
      </div>
  <?php endif; ?>
 </form>
</div>

<script>
  function previewBeforeUpload(id){
    document.querySelector("#"+id).addEventListener("change", function(e){
      if(e.target.files.length == 0){
        return;
      }
      let file = e.target.files[0];
      let url = URL.creatObjectURL(file);
      document.querySelector("#"+id+"-preview div").innerText = file.name;
      document.querySelector("#"+id+"-preview img").src = url;
    })
  }
  var imageInput = document.getElementById("image-input");
  var previewImage = document.getElementById("preview-image");
  imageInput.addEventListener("change", function(event){
    if(event.target.files.length == 0){
      return;
    }
    var tempUrl = URL.createObjectURL(event.target.files[0]);
    previewImage.setAttribute("src", tempUrl);
  });
</script>

<script>
    $(document).ready(function () {
        $('#country-dd').on('change', function () {
            var idCountry = this.value;
            $("#state-dd").html('');
            $.ajax({
                url: "<?php echo e(url('api/fetch-states')); ?>",
                type: "POST",
                data: {
                    countries_id: idCountry,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function (result) {
                    $('#state-dd').html('<option value="">Select State</option>');
                    $.each(result.states, function (key, value) {
                        $("#state-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $('#city-dd').html('<option value="">Select City</option>');
                }
            });
        });
        $('#state-dd').on('change', function () {
            var idState = this.value;
            $("#city-dd").html('');
            $.ajax({
                url: "<?php echo e(url('api/fetch-cities')); ?>",
                type: "POST",
                data: {
                    states_id: idState,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function (res) {
                    $('#city-dd').html('<option value="">Select City</option>');
                    $.each(res.cities, function (key, value) {
                        $("#city-dd").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                }
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>


      
    
<?php echo $__env->make('layouts.adminbackend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/backend/user/edit.blade.php ENDPATH**/ ?>