<div>
    <p>This is livewire component</p>
</div>
<?php /**PATH C:\xampp\htdocs\draft-artiliser\resources\views/livewire/show-posts.blade.php ENDPATH**/ ?>