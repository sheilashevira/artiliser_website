
<?php $__env->startSection('content'); ?>
<div>
  <h3 class="pt-4 px-3 text-xl text-left">Add Posts</h3>
</div>
<div class="bg-white shadow-md rounded px-10 pt-6 pb-8 mb-4 flex flex-col my-5 mx-3">
  <div class="-mx-3 md:flex mb-2">
    <div class="md:w-full px-3 mb-6 md:mb-0">
      <label class="block  tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-name">
        Name
      </label>
      <input class="appearance-none block w-full bg-grey-lighter text-sm text-grey-darker border border-red rounded py-3 px-4 mb-3" id="grid-first-name" type="text" placeholder="Input Post Name">
    </div>
  </div>
  <div class="-mx-3 md:flex mb-6">
    <div class="md:w-1/2 px-3">
      <label class="block  tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-category">
        Category
      </label>
      <select class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
      </select>
    </div>
    <div class="md:w-1/2 px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-carousel-rows">
        Carousel Rows
      </label>
      <select class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
      </select>
    </div>
  </div>
  <div class="-mx-3 md:flex mb-6">
    <div class="md:w-1/2 px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-print-materials">
        Print Materials
      </label>
      <select class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
      </select>
    </div>
    <div class="md:w-1/2 px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-print-types">
        Print Types
      </label>
      <select class="w-full bg-grey-lighter border border-grey-lighter text-sm text-grey-darker py-3 px-4 rounded mt-1 focus:outline-none focus:ring-2 focus:ring-gray-900 focus:border-transparent">
        <option>Option 1</option>
        <option>Option 2</option>
        <option>Option 3</option>
      </select>
    </div>
  </div>
  <div class="-mx-3 md:flex mb-6">
    <div class="md:w-full px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-price">
        Price
      </label>
      <input class="appearance-none block w-full bg-grey-lighter text-sm text-grey-darker border border-grey-lighter rounded py-3 px-4 mb-3" id="grid-price" type="text" placeholder="Input Price">
    </div>
    <div class="md:w-full px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-image">
        Image
      </label>
      <input class="appearance-none block w-full bg-grey-lighter text-sm text-grey-darker border border-grey-lighter rounded py-2 px-4 mb-3" id="grid-image" type="file" accept="image/png">
    </div>
  </div>
  <div class="-mx-3 md:flex mb-6">
    <div class="md:w-full px-3">
      <label class="block tracking-wide text-grey-darker text-xs font-bold mb-2" for="grid-price">
        Content
      </label>
      <div class="" x-data="app()" x-init="init($refs.wysiwyg)">
          <div class="border border-gray-200 overflow-hidden rounded-md">
              <div class="w-full flex border-b border-gray-200 text-xl text-gray-600">
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('bold')">
                      <i class="mdi mdi-format-bold"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('italic')">
                      <i class="mdi mdi-format-italic"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 mr-1 hover:text-indigo-500 active:bg-gray-50" @click="format('underline')">
                      <i class="mdi mdi-format-underline"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-l border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('formatBlock','P')">
                      <i class="mdi mdi-format-paragraph"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('formatBlock','H1')">
                      <i class="mdi mdi-format-header-1"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('formatBlock','H2')">
                      <i class="mdi mdi-format-header-2"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 mr-1 hover:text-indigo-500 active:bg-gray-50" @click="format('formatBlock','H3')">
                      <i class="mdi mdi-format-header-3"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-l border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('insertUnorderedList')">
                      <i class="mdi mdi-format-list-bulleted"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 mr-1 hover:text-indigo-500 active:bg-gray-50" @click="format('insertOrderedList')">
                      <i class="mdi mdi-format-list-numbered"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-l border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('justifyLeft')">
                      <i class="mdi mdi-format-align-left"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('justifyCenter')">
                      <i class="mdi mdi-format-align-center"></i>
                  </button>
                  <button class="outline-none focus:outline-none border-r border-gray-200 w-10 h-10 hover:text-indigo-500 active:bg-gray-50" @click="format('justifyRight')">
                      <i class="mdi mdi-format-align-right"></i>
                  </button>
              </div>
              <div class="w-full">
                  <iframe x-ref="wysiwyg" class="w-full h-96 overflow-y-auto"></iframe>
              </div>
          </div>
      </div>
    </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="bg-blue-400 px-5 py-2 text-sm shadow-sm font-semibold tracking-wider border text-blue-100 rounded-full hover:shadow-lg hover:bg-blue-500">Save</button>
    <a href="/post" class="bg-gray-300 px-5 py-2 text-sm shadow-sm font-semibold tracking-wider border text-white rounded-full hover:shadow-lg hover:bg-gray-400">Back</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

      
      
    
<?php echo $__env->make('layouts.adminbackend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser\resources\views/backend/post/add.blade.php ENDPATH**/ ?>