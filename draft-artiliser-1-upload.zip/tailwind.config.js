const colors = require('tailwindcss/colors')

module.exports = {
  purge: [
    './resources/**/*.blade.php',
    './resources/**/*.js',
    './resources/**/*.vue',
  ],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      colors: {
        table:{
          DEFAULT: '#F7DAD9',
        },
        border: {
          DEFAULT: '#D1D5DB',
        },
        artiliser: {
          DEFAULT: '#670067',
        },
        artiliserdark:{
          DEFAULT: '#3d003d',
        },
        artiliserlight:{
          DEFAULT: '#F8F0F8',
        },
        artiliserthin:{
          DEFAULT: '#FAF7FA',
        },
      },
      fontSize:{
        '3xs': '.25rem',
        '2xs': '.5rem',
      },
      width:{
        'w1': '67.75%',
        'w2': '67.65%',
        'w3': '45%',
      },
      margin: {
        'ml': '5.5rem',
       },
      screens: {
        'xs': '370px',
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [require('@tailwindcss/line-clamp'),],
}
