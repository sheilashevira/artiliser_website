
<?php $__env->startSection('content'); ?>
      <div class="container mx-auto mt-16 mt-96 lg:mt-72">
        <div class="relative flex flex-col min-w-0 break-words bg-white mb-6 shadow-xl rounded-lg -mt-96 sm:-mt-72">
          <div class="px-6">
            <div class="flex flex-wrap justify-center">
              <div class="w-full lg:w-3/12 px-4 mb-16 sm:mb-28 lg:order-2 flex justify-center">
                <div class="flex flex-col justify-center items-center relative h-full bg-black bg-opacity-50 text-white">
                <!-- <div class="relative"> -->
                  <img alt="..." src="https://image.winudf.com/v2/image/a2ltLmJ1bV9zY3JlZW5fMV8xNTI3OTAzNTA4XzA2OQ/screen-1.jpg?fakeurl=1&type=.jpg" class="rounded-full h-16 sm:h-36 w-16 sm:w-36 flex items-center justify-center align-middle border-none absolute -m-16 -ml-16 lg:-ml-16" style="max-width: 150px;" >
                </div>
              </div>
            </div>
          </div>
          <div class="text-center">
            <h3 class="text-xl sm:text-4xl font-semibold leading-normal mb-2 text-gray-800 mb-2">
              Sheila Shevira
            </h3>
            <div class="text-sm sm:text-xl leading-normal mt-0 text-gray-500 font-bold uppercase">
              <i class="fas fa-map-marker-alt mr-2 text-md text-gray-500" ></i>
                  Jimbaran, Bali
            </div>
          </div>
          <div class=" text-center py-6 px-3 mt-0">
            <a href="/edit-profile" type="button" class=" border-artiliser hover-artiliser hover:bg-artiliser hover:text-white text-artiliser mb-2 inline-flex items-center justify-center rounded px-8 py-2 text-sm md:text-base leading-2 sm:leading-6 border rounded-md shadow-sm" type="button">
              Edit Profile
            </a>
            <a href="/change-password" type="button"  class="border-artiliser hover-artiliser hover:bg-artiliser hover:text-white text-artiliser inline-flex items-center justify-center rounded px-3 py-2 text-sm md:text-base leading-2 sm:leading-6 border rounded-md shadow-sm" type="button">
              Change Password
            </a>
          </div>
          <div class="mt-5 py-5 border-t border-gray-300">
            <div class="container flex-none md:flex">
              <div class="sm:text-left text-center sm:ml-96">
              </div>
              <div class="sm:text-left text-left sm:ml-96 sm:hidden">
                <p class="text-md font-bold ml-4 leading-normal mb-2 text-gray-800">
                  Account Details
                </p>
                <div class="text-sm leading-normal ml-4 mt-0 mb-4 text-gray-500 font-normal">
                        Sheila Shevira
                    <br>Perumahan Graha Anyar Gg. IIB No.16
                    <br>Kuta Selatan
                    <br>Badung
                    <br>Bali 80361
                    <br>Indonesia
                </div>
              </div>
            </div>
            <h5 class="text-md md:text-2xl font-bold leading-normal mb-1 text-gray-800 mb-2 ml-4 md:ml-6 md:mt-2 lg:ml-16">
              Order History
            </h5>
            <div class="container flex-none md:flex">
              <table class="md:w-1/2 max-w-screen flex flex-row flex-no-wrap md:bg-white rounded-lg overflow-hidden my-5 ml-4 md:ml-6 lg:ml-16 mr-4 md:mr-10 lg:mr-0 xl:mr-6">
                <thead class="md:text-black text-white">
                  <tr class="border-grey-light border md:border-none md:bg-white bg-artiliser text-xs md:text-md flex flex-col flex-no wrap md:table-row rounded-l-lg md:rounded-none mb-2 md:mb-0">
                    <th class="p-3 text-center">Order</th>
                    <th class="p-3 text-center">Date</th>
                    <th class="p-3 text-center">Payment Status</th>
                    <th class="p-3 text-center">Fulfillment Status</th>
                    <th class="p-3 text-center">Total</th>
                  </tr>
                  <tr class="border-grey-light border md:border-none md:bg-white bg-artiliser text-xs md:text-md flex flex-col flex-no wrap md:table-row rounded-l-lg md:rounded-none mb-2 md:mb-0">
                    <th class="p-3 text-center">Order</th>
                    <th class="p-3 text-center">Date</th>
                    <th class="p-3 text-center">Payment Status</th>
                    <th class="p-3 text-center">Fulfillment Status</th>
                    <th class="p-3 text-center">Total</th>
                  </tr>
                  <tr class="border-grey-light border md:border-none md:bg-white bg-artiliser text-xs md:text-md flex flex-col flex-no wrap md:table-row rounded-l-lg md:rounded-none mb-2 md:mb-0">
                    <th class="p-3 text-center">Order</th>
                    <th class="p-3 text-center">Date</th>
                    <th class="p-3 text-center">Payment Status</th>
                    <th class="p-3 text-center">Fulfillment Status</th>
                    <th class="p-3 text-center">Total</th>
                  </tr>
                  <tr class="border-grey-light border md:border-none md:bg-white bg-artiliser text-xs md:text-md flex flex-col flex-no wrap md:table-row rounded-l-lg md:rounded-none mb-2 md:mb-0">
                    <th class="p-3 text-center">Order</th>
                    <th class="p-3 text-center">Date</th>
                    <th class="p-3 text-center">Payment Status</th>
                    <th class="p-3 text-center">Fulfillment Status</th>
                    <th class="p-3 text-center">Total</th>
                  </tr>
                </thead>
                <tbody class="flex-1 md:flex-none">
                  <tr class="border-grey-light border md:border-none flex flex-col flex-no wrap md:table-row mb-2 md:mb-0 text-xs md:text-md rounded-r-lg">
                    <td class="hover:bg-gray-100 p-3 text-center text-red-500">#10001</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">12/06/2021</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Paid</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Fulfilled</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Rp250.000,00</td>
                  </tr>
                  <tr class="border-grey-light border md:border-none flex flex-col flex-no wrap md:table-row mb-2 md:mb-0 text-xs md:text-md rounded-r-lg">
                    <td class="hover:bg-gray-100 p-3 text-center text-red-500">#10001</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">12/06/2021</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Paid</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Fulfilled</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Rp250.000,00</td>
                  </tr>
                  <tr class="border-grey-light border md:border-none flex flex-col flex-no wrap md:table-row mb-2 md:mb-0 text-xs md:text-md rounded-r-lg">
                    <td class="hover:bg-gray-100 p-3 text-center text-red-500">#10001</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">12/06/2021</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Paid</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Fulfilled</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Rp250.000,00</td>
                  </tr>
                  <tr class="border-grey-light border md:border-none flex flex-col flex-no wrap md:table-row mb-2 md:mb-0 text-xs md:text-md rounded-r-lg">
                    <td class="hover:bg-gray-100 p-3 text-center text-red-500">#10001</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">12/06/2021</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Paid</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Fulfilled</td>
                    <td class="hover:bg-gray-100 p-3 truncate text-center">Rp250.000,00</td>
                  </tr>
                </tbody>
              </table>
              <div class="md:text-left text-center lg:ml-36 md:-mt-8 hidden md:block">
                <p class="text-md font-bold leading-normal mb-2 text-gray-800">
                  Account Details
                </p>
                <div class="text-sm leading-normal mt-0 mb-2 text-gray-500 font-normal">
                        Sheila Shevira
                    <br>Perumahan Graha Anyar Gg. IIB No.16
                    <br>Kuta Selatan
                    <br>Badung
                    <br>Bali 80361
                    <br>Indonesia
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userbackend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/backend/profile/index.blade.php ENDPATH**/ ?>