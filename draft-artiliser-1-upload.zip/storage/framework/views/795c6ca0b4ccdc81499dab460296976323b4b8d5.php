<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    
    <!-- Tailwind CSS & its Custom Forms plugin -->
    <link rel="stylesheet" href="style.css"/>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.0-canary.14/tailwind.min.css" rel="stylesheet">
    <link href="/css/app.css" rel="stylesheet"/>

    <link href='https://fonts.googleapis.com/css?family=Asap' rel='stylesheet'>
    

    <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" />
    <script type="module" src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine-ie11.min.js" defer></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.js" defer></script>
    <style>
    @import  url(https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css);

    .active\:bg-gray-50:active {
        --tw-bg-opacity:1;
        background-color: rgba(249,250,251,var(--tw-bg-opacity));
    }

    a:hover {
        color: #670067;
    }
    </style>

    <script>
    function app() {
        return {
            wysiwyg: null,
            init: function(el) {
                // Get el
                this.wysiwyg = el;
                // Add CSS
                this.wysiwyg.contentDocument.querySelector('head').innerHTML += `<style>
                *, ::after, ::before {box-sizing: border-box;}
                :root {tab-size: 4;}
                html {line-height: 1.15;text-size-adjust: 100%;}
                body {margin: 0px; padding: 1rem 0.5rem;}
                body {font-family: system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji";}
                </style>`;
                this.wysiwyg.contentDocument.body.innerHTML += `
                `;
                // Make editable
                this.wysiwyg.contentDocument.designMode = "on";
            },
            format: function(cmd, param) {
                this.wysiwyg.contentDocument.execCommand(cmd, !1, param||null)
            }
        }
    }
    </script>
    <style>
        html,
        body {
            height: 100%;
        }

        @media (min-width: 640px) {
            table {
            display: inline-table !important;
            }

            thead tr:not(:first-child) {
            display: none;
            }
        }

        td:not(:last-child) {
            border-bottom: 0;
        }


        }
    </style>

    <style>
    .image-upload>input {
        display: none;
    }
    </style>
    <!-- Select2 CSS --> 
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" /> 

    <!-- jQuery --> <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 

    <!-- Select2 JS --> 
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/selector.css')); ?>">

    <style>
        body {
            font-family: 'Asap', sans-serif;
            background-color: #F8F0F8;
        }
    </style>
   
</head>
<body>
    <div class="w-full text-gray-700 bg-transparent dark-mode:text-gray-200 dark-mode:bg-gray-800" style="font-family: 'Montserrat', sans-serif;">
        <div x-data="{ open: false }" class="flex flex-col max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
            <div class="flex flex-row items-center justify-between p-4">
                <a href="#" ><img src="<?php echo e(asset('logo/logo2.png')); ?>" alt=""></a>
                <button class="rounded-lg text-artiliser lg:hidden focus:outline-none focus:shadow-outline" @click="open = !open">
                <svg fill="currentColor" viewBox="0 0 20 20" class="w-6 h-6">
                    <path x-show="!open" fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM9 15a1 1 0 011-1h6a1 1 0 110 2h-6a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                    <path x-show="open" fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                </svg>
                </button>
            </div>
            <nav :class="{'flex': open, 'hidden': !open}" class="flex-col flex-grow hidden pb-0 lg:pb-0 lg:flex lg:justify-end lg:flex-row">
                <a class="block px-4 py-1 border-b-2 border-transparent lg:p-4 hover:border-artiliser" href="#">Home</a>
                <a class="block px-4 py-1 border-b-2 border-transparent lg:p-4 hover:border-artiliser" href="#">Gallery</a>
                <a class="block px-4 py-1 border-b-2 border-transparent lg:p-4 hover:border-artiliser" href="#">About</a>
                <a class="block px-4 py-1 border-b-2 border-transparent lg:p-4 hover:border-artiliser" href="#">Contact</a>
                <a class="block px-4 py-1 mb-2 border-b-2 border-transparent lg:p-4 hover:border-artiliser lg:mb-0" href="/profile">Profile</a>
                
                <a href="/login" class="flex items-center justify-start px-4 mb-3 lg:ml-4 lg:mb-0 lg:px-0 pointer-cursor">
                    <button class="px-3 py-1 bg-transparent border rounded-lg text-artiliser border-artiliser">Login</button>
                </a>
                <a href="/register" class="flex items-center justify-start px-4 mb-4 lg:ml-4 lg:mb-0 lg:px-0 pointer-cursor">
                    <button class="px-3 py-1 text-white border rounded-lg bg-artiliser border-artiliser">Register</button>
                </a>
                <div class="hidden h-8 mt-3 mb-4 lg:flex lg:items-center lg:justify-start lg:border-l-2 lg:border-gray-300 lg:ml-4 lg:mb-0 pointer-cursor "></div>
                <a href="#" class="flex items-center justify-start px-4 mb-4 lg:ml-4 lg:mb-0 lg:px-0 pointer-cursor text-artiliser">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
                      </svg>
                </a>
            </nav>
        </div>
    </div>
    <!-- Navbar End -->

    <div class="body">
                <div style="background-color:#F8F0F8">
                    <!-- Main content -->
                    <!-- <section class="min-w-screen flex flex-col justify-center" style="height:400px; background-color:#F8F0F8">
                    </section> -->
                    <div class="container mx-auto ">
                        <div class="grid mx-10 mt-16 md:mt-1 lg:mt-36">
                                
                            <?php echo $__env->yieldContent('content'); ?>
                                
                        </div>
                    </div>
                    <!-- <section class="min-w-screen min-h-screen flex flex-col justify-center bg-gray-300">
                        
                    </section> -->
                </div>
                    <!-- /.content -->
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\draft-artiliser-1\resources\views/layouts/userbackend.blade.php ENDPATH**/ ?>