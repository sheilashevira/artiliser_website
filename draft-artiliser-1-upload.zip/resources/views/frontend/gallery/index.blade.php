@extends('layouts.userfrontend')
@section('content')
<div class="flex flex-col items-center justify-center">
  <img src="https://p4.wallpaperbetter.com/wallpaper/18/910/449/art-artist-brush-color-wallpaper-preview.jpg" alt=""class="flex items-center justify-center xl:w-full xl:h-96 lg:w-full lg:h-80 md:w-full md:h-80 sm:w-full overflow-hidden ">
    <h2 class=" text-center text-white lg:text-5xl md:text-4xl text-2xl -mt-36 mb-28 md:-mt-48 md:mb-40 lg:-mt-52 lg:mb-40" style="font-family='Asap';">Search Gallery</h2>
</div>
<div class="w-full bg-artiliserthin">
  <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
    <div class="container mx-auto">
      <div class="mx-10 -mt-12 md:-mt-12 mb-10">
        <!-- Photo Grid Card 1-->
        <div class="container md:mx-auto " x-data="loadGallery()">
          <div class="box-wrapper flex flex-row flex justify-center items-center ml-4">
            <div class=" bg-white rounded-lg flex items-center w-32 md:w-80 lg:w-96 p-3 shadow-lg border border-gray-200" style="font-family: 'Montserrat', sans-serif;">
              <button @click="getImages()" class="outline-none focus:outline-none">
                  <svg class=" w-4 md:w-5 text-gray-600 h-4 md:h-5 cursor-pointer" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24">
                    <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                  </svg>
              </button>
              <input x-ref="searchField" x-model="search" x-on:click="viewPage(0)" x-on:keydown.window.prevent.slash=" viewPage(0), $refs.searchField.focus()" placeholder="Search..." type="search" class="w-full pl-4 text-sm outline-none focus:outline-none bg-transparent">
            </div>
            <div class=" bg-white rounded-lg flex items-center w-28 md:w-28 lg:w-32 p-3 shadow-lg border border-gray-200 mx-4" style="font-family: 'Montserrat', sans-serif;">
              <div class="select">
                  <select name="" id="" class="text-xs md:text-sm outline-none focus:outline-none bg-transparent">
                    <option value="filterby" selected>Filter By</option>
                    <option value="category 1">Category 1</option>
                    <option value="category 2">Category 2</option>
                    <option value="category 3">Category 3</option>
                    </select>
              </div>  
            </div>
          </div>
          <div class="mt-12 md:mt-16 lg:mt-20 grid grid-cols-1 lg:grid-cols-3 grid-rows-2 gap-4 ">
            <template x-for="item in filteredGallery" :key="item" class="items-center container mx-auto my-auto">
              <div class="lg:flex-col items-center container mx-auto my-auto hover:shadow-lg hover:bg-artiliserlight rounded-xl">
                <div class="flex items-center justify-center">
                  <img :src="`${item.image}`" alt=""class="items-center justify-center xl:w-full xl:h-80 lg:w-full lg:h-72 md:w-4/5 md:h-96 w-full h-52 overflow-hidden rounded-3xl">
                </div>
                <div class="flex md:items-left items-center md:justify-start justify-center">
                  <div class="p-4">
                    <p x-text="item.title" class=" text-center md:text-left font-bold text-black mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 1;"></p>
                    <p x-text="item.content" class=" text-justify font-normal text-xs text-gray-400 mt-2 hidden lg:block mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 2;"></p>
                    <div class="flex justify-end items-right mx-0 sm:mx-0 md:mx-16 lg:mx-0 xl:mx-0">
                      <a href="/gallery/detail" class=" py-2 font-semibold hover:text-purple-900 text-xs text-artiliser " style="font-family: 'Montserrat', sans-serif;">Read More</a>
                    </div>
                  </div>
                </div>
              </div>
            </template>
          </div>
          <div class="w-full md:w-1/2 mx-auto py-6 flex justify-center items-center" x-show="pageCount() > 1" >
            <!--Previous Button-->
            <button x-on:click="prevPage" :disabled="pageNumber==0" :class="{ 'disabled cursor-not-allowed text-gray-600' : pageNumber==0 }" >
              <p class="border text-center md:text-left font-bold hover:text-artiliser text-gray-300 p-2 mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif;">Previous</p>
            </button>
            <!-- Display page numbers -->
            <template x-for="(page,index) in pages()" :key="index" >
              <button class="px-3 py-2 border " :class="{ 'bg-artiliser text-white font-thin' : index === pageNumber }" type="button" x-on:click="viewPage(index)" style="font-family: 'Montserrat', sans-serif;">
                <span x-text="index+1"></span>
              </button>
            </template>
            <!--Next Button-->
            <button x-on:click="nextPage" :disabled="pageNumber >= pageCount() -1" :class="{ 'disabled cursor-not-allowed text-gray-600' : pageNumber >= pageCount() -1 } " >
              <p class="border text-center md:text-left font-bold hover:text-artiliser text-gray-300 p-2 mx-0 sm:mx-0 md:mx-0 lg:mx-0 xl:mx-0" style="font-family: 'Montserrat', sans-serif;">Next</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-10 mb-20">
            <h1 class="text-2xl text-center md:text-5xl md:block mb-10" style="color:#670067; font-family:Asap; font-weight:1000">Contact Us</h1>
                <!-- Contact Us-->
                <div class="">
                    <form class="md:mx-32 lg:mx-60 xl:mx-96 space-y-6 px-8 " action="#" method="POST">
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Name" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Email" type="email" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-10 focus:placeholder-table focus:border-artiliser px-3 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="py-0 ">
                        <div class="relative ">
                            <input placeholder="Put Your Message" type="text" class="border-2 border-artiliser placeholder-table w-full rounded-lg h-40 focus:placeholder-table focus:border-artiliser px-3 pb-28 text-md" style="font-family: 'Montserrat', sans-serif;">
                        </div>
                    </div>
                    <div class="relative flex justify-center items-center">
                        <a href="#" type="submit" class="w-32 h-10 hover-artiliserdark hover:bg-artiliserdark hover:text-white flex justify-center bg-artiliser text-white p-2 rounded-lg hover:text-white" style="font-family: 'Montserrat', sans-serif;">
                        Send
                        </a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-artiliser w-full">
    <div class="max-w-screen-xl px-4 py-4 mx-auto lg:items-center lg:justify-between lg:flex-row lg:px-6 lg:px-8">
        <div class="container mx-auto">
            <div class="grid mx-10 mt-1 md:mt-3 mb-1 md:mb-3">
                <!-- Footer -->
                <div class="bottom-0 text-center">
                    <h4 class="text-xs font-medium text-white " style="font-family: 'Montserrat';"> &COPY; 2021 Artiliser. All rights reserved.</h4>
                </div>
            </div>
        </div>
    </div>
</div>
    <script>
      var sourceData = [
        {
          id: "1",
          title: "Sheila Shevira..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "2",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "3",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "4",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "5",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "6",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "7",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "8",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "9",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "10",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "11",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "12",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "13",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "14",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "15",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "16",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "17",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "18",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "19",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "20",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "21",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
        {
          id: "22",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&w=1000&q=80",
        },
        {
          id: "23",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://www.byhien.com/wp-content/uploads/2020/03/modern-paintings-art-4.jpg",
        },
        {
          id: "24",
          title: "Art deisgn theme, forest..",
          content: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas expedita quam laborum delectus Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor animi perferendis iusto, nihil quod maxime corrupti ratione aut corporis ea assumenda labore soluta quas aliquid veritatis debitis enim! Voluptatibus, ab.",
          image: "https://images.saatchiart.com/saatchi/428746/art/3808448/2878332-QXNEQJSI-7.jpg",
        },
      ];

      function loadGallery() {
        return {
          search: "",
          pageNumber: 0,
          size: 9,
          total: "",
          myForData: sourceData,

          get filteredGallery() {
            const start = this.pageNumber * this.size,
              end = start + this.size;

            if (this.search === "") {
              this.total = this.myForData.length;
              return this.myForData.slice(start, end);
            }

            //Return the total results of the filters
            this.total = this.myForData.filter((item) => {
              return item.title
                .toLowerCase()
                .includes(this.search.toLowerCase());
            }).length;

            //Return the filtered data
            return this.myForData
              .filter((item) => {
                return item.title
                  .toLowerCase()
                  .includes(this.search.toLowerCase());
              })
              .slice(start, end);
          },

          //Create array of all pages (for loop to display page numbers)
          pages() {
            return Array.from({
              length: Math.ceil(this.total / this.size),
            });
          },

          //Next Page
          nextPage() {
            this.pageNumber++;
          },

          //Previous Page
          prevPage() {
            this.pageNumber--;
          },

          //Total number of pages
          pageCount() {
            return Math.ceil(this.total / this.size);
          },

          //Return the start range of the paginated results
          startResults() {
            return this.pageNumber * this.size + 1;
          },

          //Return the end range of the paginated results
          endResults() {
            let resultsOnPage = (this.pageNumber + 1) * this.size;

            if (resultsOnPage <= this.total) {
              return resultsOnPage;
            }

            return this.total;
          },

          //Link to navigate to page
          viewPage(index) {
            this.pageNumber = index;
          },
        };
      }
    </script>
@endsection